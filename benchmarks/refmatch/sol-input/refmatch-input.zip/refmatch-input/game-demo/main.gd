extends Node3D

const GRID_SIZE := 17
const TILE := 1.2
const CENTER := 8
const APPLES_TO_LEVEL := 15
const HIGH_SCORE_PATH := "user://highscore.cfg"

const CYAN := Color("#13d9ff")
const GREEN := Color("#7dff76")
const GOLD := Color("#ffc83d")

var rng := RandomNumberGenerator.new()
var snake: Array[Vector2i] = []
var direction := Vector2i.RIGHT
var queued_direction := Vector2i.RIGHT
var obstacles: Array[Vector2i] = []
var apple := Vector2i.ZERO
var score := 0
var high_score := 0
var apples := 0
var level := 1
var elapsed := 0.0
var step_clock := 0.0
var level_clock := 0.0
var combo := 0
var last_apple_time := -INF
var state := "title"
var paused := false
var rng_seed := 0

var arena_root: Node3D
var snake_root: Node3D
var apple_root: Node3D
var camera: Camera3D
var overlay: ColorRect
var title_label: Label
var subtitle_label: Label
var hud_label: Label
var time_level_label: Label
var score_high_label: Label
var apples_label: Label
var combo_label: Label
var combo_badge: Panel
var combo_bar_fill: ColorRect
var progress_fill: ColorRect
var apple_fruit: MeshInstance3D
var warning_lights: Array[MeshInstance3D] = []
var minimap: SnakeMinimap
var objective_label: Label
var pause_label: Label
var hud_layer: CanvasLayer


func _ready() -> void:
	rng_seed = int(Time.get_unix_time_from_system()) ^ int(Time.get_ticks_usec())
	rng.seed = rng_seed
	_load_high_score()
	_build_world()
	_build_ui()
	_set_screen("title")


func _process(delta: float) -> void:
	if state == "playing" and not paused:
		elapsed += delta
		if combo > 0 and elapsed - last_apple_time > 4.0:
			combo = 0
		step_clock += delta
		while step_clock >= _step_interval():
			step_clock -= _step_interval()
			_advance_snake()
			if state != "playing":
				break
	elif state == "level_complete":
		level_clock += delta
		if level_clock >= 2.0:
			_begin_level_two()
	if apple_fruit != null and is_instance_valid(apple_fruit):
		var shimmer := 1.0 + sin(Time.get_ticks_msec() * 0.003) * 0.035
		apple_fruit.scale = Vector3(shimmer, 1.0 / shimmer, shimmer)
	for i in range(warning_lights.size()):
		warning_lights[i].scale = Vector3.ONE * (0.8 + 0.35 * (0.5 + 0.5 * sin(elapsed * 2.4 + float(i))))
	_update_hud()
	if minimap != null:
		minimap.update_state(snake, apple)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var key := event as InputEventKey
		if state == "title" and (key.keycode == KEY_ENTER or key.keycode == KEY_KP_ENTER):
			_start_game()
			return
		if (state == "game_over" or state == "level_complete") and (key.keycode == KEY_ENTER or key.keycode == KEY_KP_ENTER):
			_start_game()
			return
		if state == "playing":
			if key.keycode == KEY_ESCAPE or key.keycode == KEY_P:
				paused = not paused
				pause_label.visible = paused
				return
			var candidate := Vector2i.ZERO
			match key.keycode:
				KEY_UP, KEY_W: candidate = Vector2i.UP
				KEY_DOWN, KEY_S: candidate = Vector2i.DOWN
				KEY_LEFT, KEY_A: candidate = Vector2i.LEFT
				KEY_RIGHT, KEY_D: candidate = Vector2i.RIGHT
			if candidate != Vector2i.ZERO and candidate != -direction:
				queued_direction = candidate
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if state == "title" or state == "game_over" or state == "level_complete":
			_start_game()


func _build_world() -> void:
	var world := WorldEnvironment.new()
	var environment := Environment.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("#0A1420")
	sky_material.sky_horizon_color = Color("#1B3A58")
	sky_material.ground_bottom_color = Color("#030507")
	sky_material.ground_horizon_color = Color("#060A10")
	var sky := Sky.new()
	sky.sky_material = sky_material
	environment.background_mode = Environment.BG_SKY
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.ambient_light_sky_contribution = 0.55
	environment.ambient_light_energy = 0.5
	environment.background_energy_multiplier = 1.35
	environment.tonemap_mode = Environment.TONE_MAPPER_ACES
	environment.tonemap_exposure = 0.92
	environment.glow_enabled = true
	environment.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	environment.glow_intensity = 0.45
	environment.glow_strength = 1.0
	environment.glow_hdr_threshold = 0.9
	environment.fog_enabled = true
	environment.fog_light_color = Color("#10222F")
	environment.fog_density = 0.02
	environment.fog_sky_affect = 0.25
	environment.ssao_enabled = true
	world.environment = environment
	add_child(world)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_color = Color("#bfe3ff")
	sun.light_energy = 0.7
	sun.shadow_enabled = true
	sun.shadow_blur = 2.0
	sun.directional_shadow_blend_splits = true
	add_child(sun)

	var rim := DirectionalLight3D.new()
	rim.rotation_degrees = Vector3(-38, 155, 0)
	rim.light_color = Color("#57C8FF")
	rim.light_energy = 0.55
	rim.shadow_enabled = false
	add_child(rim)

	camera = Camera3D.new()
	camera.position = Vector3(0.0, 18.5, 26.6)
	camera.current = true
	camera.fov = 33.7
	add_child(camera)
	camera.look_at(Vector3(0, 1.5, 0), Vector3.UP)

	arena_root = Node3D.new()
	arena_root.name = "Arena"
	add_child(arena_root)
	_build_arena()

	snake_root = Node3D.new()
	snake_root.name = "Snake"
	add_child(snake_root)
	apple_root = Node3D.new()
	apple_root.name = "Apple"
	add_child(apple_root)


func _build_arena() -> void:
	var floor_texture := load("res://assets/tex-floor.png") as Texture2D
	var surface_noise := FastNoiseLite.new()
	surface_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	surface_noise.frequency = 0.035
	var roughness_noise := NoiseTexture2D.new()
	roughness_noise.width = 128
	roughness_noise.height = 128
	roughness_noise.seamless = true
	roughness_noise.noise = surface_noise
	var exterior_material := _material(Color("#33445A"), 0.15, 0.68)
	exterior_material.albedo_texture = floor_texture
	exterior_material.uv1_scale = Vector3(9.0, 9.0, 1.0)
	var exterior_floor := _box(Vector3(70.0, 0.12, 70.0))
	_add_mesh(arena_root, exterior_floor, Vector3(0, -0.82, 0), exterior_material)
	var floor_material := _material(Color("#546C88"), 0.3, 0.44)
	floor_material.albedo_texture = floor_texture
	floor_material.uv1_scale = Vector3(7.0, 7.0, 1.0)
	floor_material.normal_enabled = true
	floor_material.normal_texture = load("res://assets/tex-floor-n.png")
	floor_material.normal_scale = 1.0
	var floor_mesh := BoxMesh.new()
	floor_mesh.size = Vector3(GRID_SIZE * TILE, 0.25, GRID_SIZE * TILE)
	_add_mesh(arena_root, floor_mesh, Vector3(0, -0.2, 0), floor_material)
	var under_mesh := BoxMesh.new()
	under_mesh.size = Vector3(GRID_SIZE * TILE + 1.0, 0.45, GRID_SIZE * TILE + 1.0)
	_add_mesh(arena_root, under_mesh, Vector3(0, -0.58, 0), _material(Color("#09111a"), 0.72, 0.55))
	# Fine metal grid lines and luminous perimeter inlays.
	for i in range(GRID_SIZE + 1):
		var offset := (float(i) - CENTER) * TILE - TILE * 0.5
		var line_mesh := BoxMesh.new()
		line_mesh.size = Vector3(0.05, 0.014, GRID_SIZE * TILE)
		_add_mesh(arena_root, line_mesh, Vector3(offset, -0.064, 0), _glow_material(Color("#0e5566"), 0.32))
		var cross_mesh := BoxMesh.new()
		cross_mesh.size = Vector3(GRID_SIZE * TILE, 0.014, 0.05)
		_add_mesh(arena_root, cross_mesh, Vector3(0, -0.064, offset), _glow_material(Color("#0e5566"), 0.32))
	var span := GRID_SIZE * TILE
	for edge in [-1, 1]:
		var wall := BoxMesh.new()
		wall.size = Vector3(span + 0.48, 1.25, 0.42)
		_add_mesh(arena_root, wall, Vector3(0, 0.5, edge * (span * 0.5 + 0.03)), _material(Color("#0d1620"), 0.7, 0.45))
		_add_frame_trim(span + 0.52, 0.48, Vector3(0, 0, edge * (span * 0.5 + 0.03)))
		var side_wall := BoxMesh.new()
		side_wall.size = Vector3(0.42, 1.25, span + 0.48)
		_add_mesh(arena_root, side_wall, Vector3(edge * (span * 0.5 + 0.03), 0.5, 0), _material(Color("#0d1620"), 0.7, 0.45))
		_add_frame_trim(0.48, span + 0.52, Vector3(edge * (span * 0.5 + 0.03), 0, 0))
	# Eight fixed crates leave a generous opening around the spawn lane.
	obstacles = [Vector2i(-5, -4), Vector2i(-5, -3), Vector2i(5, -4), Vector2i(5, -3), Vector2i(-5, 4), Vector2i(-5, 5), Vector2i(5, 4), Vector2i(5, 5)]
	var crate_colors := [Color("#262e37"), Color("#2c333b"), Color("#232a33")]
	for crate_index in range(obstacles.size()):
		var cell: Vector2i = obstacles[crate_index]
		var crate := BoxMesh.new()
		crate.size = Vector3(TILE * 0.82, 0.82, TILE * 0.82)
		var pos := _cell_to_world(cell)
		_add_mesh(arena_root, crate, pos + Vector3(0, 0.43, 0), _material(crate_colors[crate_index % crate_colors.size()], 0.8, 0.3))
		_add_mesh(arena_root, _box(Vector3(TILE * 0.84, 0.045, TILE * 0.84)), pos + Vector3(0, 0.86, 0), _glow_material(Color("#266580"), 0.55))
		_add_mesh(arena_root, _box(Vector3(TILE * 0.7, 0.04, 0.08)), pos + Vector3(0, 0.88, 0), _material(Color("#536c79"), 0.7, 0.25))

	_add_hazard_stripes(span)
	_build_industrial_details(span)
	_build_dressing_clusters()


func _add_hazard_stripes(span: float) -> void:
	var stripe_colors := [_material(Color("#b98a1f"), 0.35, 0.6), _material(Color("#11161d"), 0.4, 0.6)]
	var half := span * 0.5 + 0.03
	var i := 0
	var x := -span * 0.5 + 0.35
	while x < span * 0.5:
		for edge in [-1, 1]:
			_add_mesh(arena_root, _box(Vector3(0.62, 0.03, 0.5)), Vector3(x, 1.175, edge * half), stripe_colors[i % 2])
			_add_mesh(arena_root, _box(Vector3(0.5, 0.03, 0.62)), Vector3(edge * half, 1.175, x), stripe_colors[i % 2])
		x += 0.72
		i += 1


func _add_frame_trim(width: float, depth: float, base_pos: Vector3) -> void:
	var trim_size := Vector3(width, 0.035, depth)
	var rail_size := Vector3(width + 0.04, 0.03, depth + 0.04)
	_add_mesh(arena_root, _box(trim_size), base_pos + Vector3(0, 1.09, 0), _glow_material(Color("#0E7C99"), 1.15))
	for rail_y in [0.99, 1.14]:
		_add_mesh(arena_root, _box(rail_size), base_pos + Vector3(0, rail_y, 0), _material(Color("#0d1620"), 0.7, 0.45))


func _build_industrial_details(span: float) -> void:
	# A low-contrast industrial shell sits beyond the playable footprint.
	var wall_texture := load("res://assets/tex-wall.png") as Texture2D
	var room_material := _material(Color("#7e8fa0"), 0.3, 0.6)
	room_material.albedo_texture = wall_texture
	room_material.uv1_scale = Vector3(6.0, 2.0, 1.0)
	room_material.normal_enabled = true
	room_material.normal_texture = load("res://assets/tex-wall-n.png")
	room_material.normal_scale = 1.0
	var room_height := 14.0
	var wall_center_y := 6.18
	var back_wall := _box(Vector3(45.0, room_height, 0.55))
	_add_mesh(arena_root, back_wall, Vector3(0, wall_center_y, -17.0), room_material)
	for side in [-1.0, 1.0]:
		var side_panel := _box(Vector3(0.55, room_height, 45.0))
		_add_mesh(arena_root, side_panel, Vector3(side * 17.0, wall_center_y, 0), room_material)
	# The back wall is built from oversized industrial plates with visible inset seams.
	var seam_material := _material(Color("#0a0f16"), 0.3, 0.75)
	for x in range(-20, 21, 4):
		_add_mesh(arena_root, _box(Vector3(0.055, room_height - 0.3, 0.045)), Vector3(float(x), wall_center_y, -16.69), seam_material)
	for y in range(0, 14, 3):
		_add_mesh(arena_root, _box(Vector3(44.5, 0.055, 0.045)), Vector3(0, float(y) + 0.35, -16.69), seam_material)
	# Five proud vertical pilasters articulate the large back-wall plane.
	for x in [-19.0, -9.5, 0.0, 9.5, 19.0]:
		_add_mesh(arena_root, _box(Vector3(0.48, room_height + 0.2, 0.3)), Vector3(x, wall_center_y, -16.58), _material(Color("#141e29"), 0.6, 0.48))
	# Three horizontal pipe runs and restrained cyan practical lights.
	for y in [2.0, 4.6, 7.2]:
		var back_pipe := CylinderMesh.new()
		back_pipe.top_radius = 0.16
		back_pipe.bottom_radius = 0.16
		back_pipe.height = 32.0
		var pipe_node := _add_mesh(arena_root, back_pipe, Vector3(0, y, -16.55), _material(Color("#141E29"), 0.4, 0.6))
		pipe_node.rotation.z = PI / 2.0
	# Two larger service risers and a high transverse run add a second pipe scale.
	for x in [-21.0, 21.0]:
		var riser := CylinderMesh.new()
		riser.top_radius = 0.22
		riser.bottom_radius = 0.22
		riser.height = 12.8
		_add_mesh(arena_root, riser, Vector3(x, 6.0, -16.54), _material(Color("#18222e"), 0.55, 0.48))
	var high_run := CylinderMesh.new()
	high_run.top_radius = 0.22
	high_run.bottom_radius = 0.22
	high_run.height = 38.0
	var high_run_node := _add_mesh(arena_root, high_run, Vector3(0, 10.4, -16.54), _material(Color("#18222e"), 0.55, 0.48))
	high_run_node.rotation.z = PI / 2.0
	for y in [1.0, 8.4]:
		_add_mesh(arena_root, _box(Vector3(27.0, 0.045, 0.035)), Vector3(0, y, -16.68), _glow_material(Color("#2FB9D8"), 1.6))
	# Horizon strip light at the top of the camera-visible wall slice (y~1.9).
	_add_mesh(arena_root, _box(Vector3(30.0, 0.12, 0.06)), Vector3(0, 1.85, -16.68), _glow_material(Color("#2FB9D8"), 1.2))
	# Lit windows inside the camera-visible wall slice (bottom ~2m of the wall).
	var window_mats := [_glow_material(Color("#2FB9D8"), 0.85), _glow_material(Color("#FFB347"), 0.85)]
	var wi := 0
	for row_y in [0.85, 1.55]:
		var wx := -15.0
		while wx <= 15.0:
			if (wi + int(row_y * 10.0)) % 4 != 3:
				_add_mesh(arena_root, _box(Vector3(1.5, 0.45, 0.06)), Vector3(wx, row_y, -16.68), window_mats[wi % 2])
			wx += 3.0
			wi += 1
	var wall_uplight := OmniLight3D.new()
	wall_uplight.position = Vector3(0, 1.5, -12.5)
	wall_uplight.light_color = Color("#7FB2D9")
	wall_uplight.light_energy = 1.2
	wall_uplight.omni_range = 15.0
	arena_root.add_child(wall_uplight)
	var wall_wash := OmniLight3D.new()
	wall_wash.position = Vector3(0, 5.2, -15.2)
	wall_wash.light_color = Color("#2FB9D8")
	wall_wash.light_energy = 1.3
	wall_wash.omni_range = 20.0
	arena_root.add_child(wall_wash)
	var warm_key := OmniLight3D.new()
	warm_key.position = Vector3(11.0, 12.0, 11.0)
	warm_key.light_color = Color("#FFB37A")
	warm_key.light_energy = 1.1
	warm_key.omni_range = 42.0
	arena_root.add_child(warm_key)
	# Three amber practicals cast individual light pools across the room.
	for x in [-13.0, 0.0, 13.0]:
		var practical_pos := Vector3(x, 6.0, -16.55)
		_add_mesh(arena_root, _box(Vector3(1.25, 0.42, 0.16)), practical_pos, _glow_material(Color("#ff9a3c"), 1.8))
		var practical := OmniLight3D.new()
		practical.position = practical_pos + Vector3(0, -0.4, 0.7)
		practical.light_color = Color("#ff9a3c")
		practical.light_energy = 1.4
		practical.omni_range = 9.0
		arena_root.add_child(practical)
	var left_room_wash := OmniLight3D.new()
	left_room_wash.position = Vector3(-13.0, 10.5, 0.0)
	left_room_wash.light_color = Color("#33506B")
	left_room_wash.light_energy = 0.35
	left_room_wash.omni_range = 26.0
	arena_root.add_child(left_room_wash)
	for px in [-8.0, 8.0]:
		_add_mesh(arena_root, _box(Vector3(1.3, 0.32, 0.18)), Vector3(px, 4.2, -16.6), _glow_material(Color("#ff9a3c"), 1.15))
		var practical := OmniLight3D.new()
		practical.position = Vector3(px, 4.2, -15.4)
		practical.light_color = Color("#ff9a3c")
		practical.light_energy = 1.0
		practical.omni_range = 13.0
		arena_root.add_child(practical)
	# Alternating hazard-stripe panel on the back wall, kept intentionally dim.
	for i in range(28):
		var stripe := _box(Vector3(0.42, 0.9, 0.035))
		var stripe_color := Color("#C99700") if i % 2 == 0 else Color("#0A0A0A")
		_add_mesh(arena_root, stripe, Vector3(-6.0 + float(i) * 0.45, 1.6, -16.68), _material(stripe_color, 0.25, 0.62))
	# Alternating hazard bands across the inside face of the four arena walls.
	for edge in [-1.0, 1.0]:
		for i in range(19):
			var stripe_color := Color("#d8a012") if i % 2 == 0 else Color("#0a0a0a")
			var x := -10.2 + float(i) * 1.14
			_add_mesh(arena_root, _box(Vector3(0.55, 0.09, 0.035)), Vector3(x, 0.02, edge * 10.01), _material(stripe_color, 0.3, 0.45))
			_add_mesh(arena_root, _box(Vector3(0.035, 0.09, 0.55)), Vector3(edge * 10.01, 0.02, x), _material(stripe_color, 0.3, 0.45))
	# Pipe runs and industrial drums sit beyond the playable wall.
	for side in [-1.0, 1.0]:
		var pipe_mesh := CylinderMesh.new()
		pipe_mesh.top_radius = 0.105
		pipe_mesh.bottom_radius = 0.105
		pipe_mesh.height = span - 2.0
		var pipe := _add_mesh(arena_root, pipe_mesh, Vector3(side * 11.2, 0.18, 0), _material(Color("#1B2735"), 0.4, 0.6))
		pipe.rotation.x = PI / 2.0
		for z in [-6.0, 0.0, 6.0]:
			var barrel_mesh := CylinderMesh.new()
			barrel_mesh.top_radius = 0.43
			barrel_mesh.bottom_radius = 0.43
			barrel_mesh.height = 1.05
			var barrel_x: float = side * 11.65
			_add_mesh(arena_root, barrel_mesh, Vector3(barrel_x, 0.52, z), _material(Color("#1B2735"), 0.4, 0.6))
			var band := TorusMesh.new()
			band.inner_radius = 0.36
			band.outer_radius = 0.42
			var band_node := _add_mesh(arena_root, band, Vector3(barrel_x, 0.52, z), _material(Color("#202a34"), 0.88, 0.3))
			band_node.rotation.x = PI / 2.0
	# Red beacons identify the four wall corners.
	for x in [-10.35, 10.35]:
		for z in [-10.35, 10.35]:
			var beacon := _sphere(arena_root, Vector3(x, 1.42, z), 0.13, _glow_material(Color("#ff2a1e"), 3.0))
			warning_lights.append(beacon)
			var point := OmniLight3D.new()
			point.position = Vector3(x, 1.4, z)
			point.light_color = Color("#ff2a1e")
			point.light_energy = 0.8
			point.omni_range = 2.5
			arena_root.add_child(point)


func _build_dressing_clusters() -> void:
	var cluster_centers := [Vector2(-11.5, 11.5), Vector2(11.5, 11.5), Vector2(-11.5, -11.5), Vector2(11.5, -11.5)]
	var crate_tints := [Color("#262e37"), Color("#2c333b"), Color("#232a33")]
	var floor_y := -0.82
	for cluster_index in range(cluster_centers.size()):
		var center: Vector2 = cluster_centers[cluster_index]
		for crate_index in range(3):
			var width := 1.0 + float((cluster_index + crate_index) % 3) * 0.25
			var depth := 0.9 + float((cluster_index * 2 + crate_index) % 3) * 0.25
			var height := 0.8 + float((cluster_index + crate_index * 2) % 4) * 0.2
			var offset := Vector3(float(crate_index - 1) * 0.72, 0.0, 0.0)
			var crate := _box(Vector3(width, height, depth))
			_add_mesh(arena_root, crate, Vector3(center.x, floor_y + height * 0.5, center.y) + offset, _material(crate_tints[(cluster_index + crate_index) % crate_tints.size()], 0.55, 0.62))
		# Two low crates support one elevated case for a clear stacked silhouette.
		var top_size := Vector3(1.05, 0.9, 1.05)
		_add_mesh(arena_root, _box(top_size), Vector3(center.x, floor_y + 1.0 + top_size.y * 0.5, center.y - 0.12), _material(crate_tints[cluster_index % crate_tints.size()], 0.55, 0.62))
		if cluster_index < 3:
			var barrel := CylinderMesh.new()
			barrel.top_radius = 0.42
			barrel.bottom_radius = 0.42
			barrel.height = 1.1
			var barrel_color := Color("#4a2e22") if cluster_index == 1 else Color("#1e2833")
			_add_mesh(arena_root, barrel, Vector3(center.x + 1.15, -0.27, center.y + 0.2), _material(barrel_color, 0.62, 0.5))


func _sphere(parent: Node3D, pos: Vector3, radius: float, material: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	return _add_mesh(parent, mesh, pos, material)


func _build_ui() -> void:
	hud_layer = CanvasLayer.new()
	add_child(hud_layer)
	var topbar := ColorRect.new()
	topbar.color = Color(0.012, 0.027, 0.045, 0.96)
	topbar.position = Vector2(0, 0)
	topbar.size = Vector2(1280, 94)
	hud_layer.add_child(topbar)
	var left_panel := _panel(Vector2(18, 10), Vector2(326, 74))
	var center_panel := _panel(Vector2(357, 10), Vector2(550, 74))
	var right_panel := _panel(Vector2(921, 10), Vector2(341, 74))
	hud_layer.add_child(left_panel)
	hud_layer.add_child(center_panel)
	hud_layer.add_child(right_panel)
	time_level_label = _label("TIME 00:00     •     LEVEL 1", 20, Color("#e8f7ff"), Vector2(34, 22), Vector2(294, 42), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(time_level_label)
	score_high_label = _label("SCORE 000000    •    HIGH 000000", 20, Color("#fff0bb"), Vector2(372, 20), Vector2(520, 36), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(score_high_label)
	combo_badge = Panel.new()
	combo_badge.position = Vector2(499, 50)
	combo_badge.size = Vector2(266, 30)
	var badge_style := StyleBoxFlat.new()
	badge_style.bg_color = Color(0.05, 0.17, 0.11, 0.95)
	badge_style.border_color = Color("#2fae62")
	badge_style.set_border_width_all(1)
	badge_style.set_corner_radius_all(15)
	combo_badge.add_theme_stylebox_override("panel", badge_style)
	hud_layer.add_child(combo_badge)
	combo_label = _label("COMBO x2  •  4.0s", 17, Color("#7dffb6"), Vector2(372, 53), Vector2(520, 25), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(combo_label)
	var pill := Panel.new()
	pill.position = Vector2(470, 100)
	pill.size = Vector2(340, 30)
	var pill_style := StyleBoxFlat.new()
	pill_style.bg_color = Color(0.03, 0.08, 0.12, 0.92)
	pill_style.border_color = Color("#c9a227")
	pill_style.set_border_width_all(1)
	pill_style.set_corner_radius_all(15)
	pill.add_theme_stylebox_override("panel", pill_style)
	hud_layer.add_child(pill)
	var pill_label := _label("OBJECTIVE — COLLECT 15 APPLES", 14, Color("#ffe59a"), Vector2(470, 104), Vector2(340, 22), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(pill_label)
	hud_label = score_high_label # Preserve the Wave 1 public HUD reference.
	var apple_text := _label("APPLES 00/15   •   0%", 17, Color("#ffe59a"), Vector2(936, 14), Vector2(310, 28), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(apple_text)
	apples_label = apple_text
	var progress_track := ColorRect.new()
	progress_track.color = Color("#233b4c")
	progress_track.position = Vector2(948, 55)
	progress_track.size = Vector2(288, 9)
	hud_layer.add_child(progress_track)
	progress_fill = ColorRect.new()
	progress_fill.color = Color("#5de5b1")
	progress_fill.size = Vector2(0, 9)
	progress_track.add_child(progress_fill)
	var combo_track := ColorRect.new()
	combo_track.color = Color("#183d38")
	combo_track.position = Vector2(500, 80)
	combo_track.size = Vector2(264, 5)
	hud_layer.add_child(combo_track)
	combo_bar_fill = ColorRect.new()
	combo_bar_fill.color = Color("#65ffac")
	combo_bar_fill.size = Vector2(0, 5)
	combo_track.add_child(combo_bar_fill)
	var bottom := ColorRect.new()
	bottom.color = Color(0.012, 0.027, 0.045, 0.96)
	bottom.position = Vector2(0, 656)
	bottom.size = Vector2(1280, 64)
	hud_layer.add_child(bottom)
	objective_label = _label("COLLECT 15 APPLES     •     ARROWS / WASD MOVE     •     ESC / P PAUSE", 17, Color("#a5c6d8"), Vector2(32, 670), Vector2(1216, 34), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(objective_label)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.025, 0.045, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.offset_top = 94
	dim.offset_bottom = -64
	hud_layer.add_child(dim)
	overlay = dim
	title_label = _label("TRIPLE AAA SNAKE", 58, Color("#eaf8ff"), Vector2(0, 238), Vector2(1280, 80), HORIZONTAL_ALIGNMENT_CENTER)
	title_label.add_theme_color_override("font_shadow_color", Color("#0bdbff"))
	title_label.add_theme_constant_override("shadow_offset_x", 0)
	title_label.add_theme_constant_override("shadow_offset_y", 0)
	title_label.add_theme_constant_override("shadow_outline_size", 2)
	hud_layer.add_child(title_label)
	subtitle_label = _label("CLICK OR PRESS ENTER TO START", 23, Color("#82eaff"), Vector2(0, 337), Vector2(1280, 48), HORIZONTAL_ALIGNMENT_CENTER)
	hud_layer.add_child(subtitle_label)
	pause_label = _label("PAUSED", 46, Color("#eaf8ff"), Vector2(0, 306), Vector2(1280, 64), HORIZONTAL_ALIGNMENT_CENTER)
	pause_label.visible = false
	hud_layer.add_child(pause_label)
	minimap = SnakeMinimap.new()
	minimap.name = "MAP"
	minimap.position = Vector2(1090, 514)
	minimap.size = Vector2(166, 132)
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(minimap)


class SnakeMinimap extends Control:
	var cells: Array[Vector2i] = []
	var food := Vector2i.ZERO

	func update_state(source: Array[Vector2i], apple_cell: Vector2i) -> void:
		cells = source.duplicate()
		food = apple_cell
		queue_redraw()

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color("#08111a"))
		draw_rect(Rect2(Vector2.ONE, size - Vector2(2, 2)), Color("#0d1822"))
		draw_string(get_theme_default_font(), Vector2(9, 17), "MAP", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#72b7c8"))
		var bounds := Rect2(9, 24, size.x - 18, size.y - 32)
		var cell_size := bounds.size / 17.0
		draw_rect(bounds, Color("#101c27"))
		for i in range(18):
			var offset := float(i) * cell_size.x
			draw_line(bounds.position + Vector2(offset, 0), bounds.position + Vector2(offset, bounds.size.y), Color(0.12, 0.29, 0.35, 0.45), 0.6)
			offset = float(i) * cell_size.y
			draw_line(bounds.position + Vector2(0, offset), bounds.position + Vector2(bounds.size.x, offset), Color(0.12, 0.29, 0.35, 0.45), 0.6)
		draw_rect(bounds, Color("#315061"), false, 1.0)
		var apple_pos := bounds.position + (Vector2(food.x + 8.5, food.y + 8.5)) * cell_size
		draw_circle(apple_pos, 3.4, Color("#ffb300"))
		if cells.size() > 1:
			var line_points := PackedVector2Array()
			for map_cell in cells:
				line_points.append(bounds.position + Vector2(map_cell.x + 8.5, map_cell.y + 8.5) * cell_size)
			draw_polyline(line_points, Color("#2fae4e"), 2.2)
		for i in range(cells.size() - 1, -1, -1):
			var cell := cells[i]
			var pos := bounds.position + Vector2(cell.x + 8.5, cell.y + 8.5) * cell_size
			if i == 0:
				draw_circle(pos, 3.2, Color("#F0FFD8"))
			else:
				draw_circle(pos, 2.6, Color("#46FF5E"))


func _panel(pos: Vector2, size: Vector2) -> Panel:
	var panel := Panel.new()
	panel.position = pos
	panel.size = size
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.10, 0.14, 0.95)
	style.border_color = Color("#1d5b74")
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	panel.add_theme_stylebox_override("panel", style)
	return panel

func _start_game() -> void:
	score = 0
	apples = 0
	combo = 0
	last_apple_time = -INF
	level = 1
	elapsed = 0.0
	step_clock = 0.0
	paused = false
	state = "playing"
	snake = [Vector2i(0, 0), Vector2i(-1, 0), Vector2i(-2, 0)]
	direction = Vector2i.RIGHT
	queued_direction = direction
	_spawn_apple()
	_render_snake()
	_set_screen("playing")


func _begin_level_two() -> void:
	level = 2
	combo = 0
	last_apple_time = -INF
	apples = 0
	step_clock = 0.0
	snake = [Vector2i(0, 0), Vector2i(-1, 0), Vector2i(-2, 0)]
	direction = Vector2i.RIGHT
	queued_direction = direction
	_spawn_apple()
	_render_snake()
	state = "playing"
	_set_screen("playing")


func _advance_snake() -> void:
	direction = queued_direction
	var next := snake[0] + direction
	if abs(next.x) > CENTER or abs(next.y) > CENTER or obstacles.has(next):
		_end_game()
		return
	var eating := next == apple
	if snake.has(next) and not (next == snake[-1] and not eating):
		_end_game()
		return
	snake.push_front(next)
	if eating:
		if elapsed - last_apple_time <= 4.0:
			combo += 1
		else:
			combo = 1
		last_apple_time = elapsed
		_spawn_eat_sparkles(_cell_to_world(apple) + Vector3(0, 0.32, 0))
		score += 100 * combo
		apples += 1
		if score > high_score:
			high_score = score
			_save_high_score()
		if apples >= APPLES_TO_LEVEL and level == 1:
			state = "level_complete"
			level_clock = 0.0
			_set_screen("level_complete")
		else:
			_spawn_apple()
	else:
		snake.pop_back()
	_render_snake()


func _spawn_apple() -> void:
	var free_cells: Array[Vector2i] = []
	for x in range(-CENTER, CENTER + 1):
		for y in range(-CENTER, CENTER + 1):
			var cell := Vector2i(x, y)
			if not snake.has(cell) and not obstacles.has(cell):
				free_cells.append(cell)
	if free_cells.is_empty():
		return
	apple = free_cells[rng.randi_range(0, free_cells.size() - 1)]
	for child in apple_root.get_children():
		child.queue_free()
	var at := _cell_to_world(apple)
	var pedestal := CylinderMesh.new()
	pedestal.top_radius = 0.31
	pedestal.bottom_radius = 0.4
	pedestal.radial_segments = 6
	pedestal.height = 0.16
	_add_mesh(apple_root, pedestal, at + Vector3(0, 0.08, 0), _material(Color("#10161d"), 0.82, 0.3))
	var pedestal_ring := TorusMesh.new()
	pedestal_ring.inner_radius = 0.29
	pedestal_ring.outer_radius = 0.36
	var pedestal_ring_node := _add_mesh(apple_root, pedestal_ring, at + Vector3(0, 0.17, 0), _glow_material(CYAN, 2.2))
	pedestal_ring_node.rotation.x = PI / 2.0
	var fruit := SphereMesh.new()
	fruit.radius = 0.46
	fruit.height = 0.92
	apple_fruit = _add_mesh(apple_root, fruit, at + Vector3(0, 0.56, 0), _glow_material(Color("#E07B00"), 1.2))
	apple_fruit.name = "AppleFruit"
	var stem := CylinderMesh.new()
	stem.top_radius = 0.035
	stem.bottom_radius = 0.055
	stem.height = 0.2
	_add_mesh(apple_root, stem, at + Vector3(0, 0.95, 0), _material(Color("#55d56a"), 0.35, 0.15))
	var leaf := SphereMesh.new()
	leaf.radius = 0.11
	leaf.height = 0.06
	_add_mesh(apple_root, leaf, at + Vector3(0.1, 1.0, 0), _material(Color("#71ff88"), 0.3, 0.1))
	var glow := OmniLight3D.new()
	glow.position = at + Vector3(0, 0.62, 0)
	glow.light_color = Color("#FFB300")
	glow.light_energy = 2.0
	glow.omni_range = 3.5
	apple_root.add_child(glow)


func _spawn_eat_sparkles(at: Vector3) -> void:
	var particles := GPUParticles3D.new()
	particles.name = "AppleEatSparkles"
	particles.position = at
	particles.amount = 28
	particles.lifetime = 0.85
	particles.one_shot = true
	particles.explosiveness = 0.9
	particles.emitting = true
	particles.visibility_aabb = AABB(Vector3(-3, -2, -3), Vector3(6, 6, 6))
	var process_material := ParticleProcessMaterial.new()
	process_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	process_material.emission_sphere_radius = 0.2
	process_material.direction = Vector3(0, 1, 0)
	process_material.spread = 180.0
	process_material.initial_velocity_min = 1.8
	process_material.initial_velocity_max = 4.2
	process_material.gravity = Vector3(0, -1.2, 0)
	process_material.scale_min = 0.035
	process_material.scale_max = 0.085
	process_material.color = GOLD.lightened(0.15)
	particles.process_material = process_material
	var sparkle := SphereMesh.new()
	sparkle.radius = 0.055
	sparkle.height = 0.11
	particles.draw_pass_1 = sparkle
	particles.material_override = _glow_material(GOLD, 3.5)
	add_child(particles)
	particles.finished.connect(particles.queue_free)


func _render_snake() -> void:
	for child in snake_root.get_children():
		child.queue_free()
	for i in range(snake.size()):
		var cell := snake[i]
		var at := _cell_to_world(cell)
		var is_head := i == 0
		if is_head:
			var head_mesh := SphereMesh.new()
			head_mesh.radius = 0.48
			head_mesh.height = 0.96
			var head_material := _material(Color("#b9ccdd"), 0.6, 0.34)
			head_material.albedo_texture = load("res://assets/tex-snake.png")
			head_material.normal_enabled = true
			head_material.normal_texture = load("res://assets/tex-snake-n.png")
			head_material.normal_scale = 1.4
			head_material.uv1_scale = Vector3(1.5, 0.75, 1.0)
			var head := _add_mesh(snake_root, head_mesh, at + Vector3(0, 0.54, 0), head_material)
			var head_axis := Vector3(direction.x, 0, direction.y).normalized()
			if head_axis.length_squared() > 0.5:
				head.basis = Basis(Quaternion(Vector3.UP, head_axis))
			head.scale = Vector3(1.0, 1.25, 1.0)
			var forward := head_axis
			var side := Vector3(-direction.y, 0, direction.x).normalized()
			var jaw_mesh := BoxMesh.new()
			jaw_mesh.size = Vector3(0.56, 0.15, 0.34)
			var jaw := _add_mesh(snake_root, jaw_mesh, at + Vector3(0, 0.25, 0) + forward * 0.31, _material(Color("#263544"), 0.75, 0.36))
			jaw.rotation.y = atan2(direction.x, direction.y)
			for sign in [-1.0, 1.0]:
				var eye_pos: Vector3 = at + Vector3(0, 0.82, 0) + forward * 0.33 + side * 0.21 * sign
				var eye := _sphere(snake_root, eye_pos, 0.115, _glow_material(Color("#00e065"), 1.35))
				eye.scale = Vector3(1.5, 0.42, 0.8)
				eye.rotation.y = atan2(direction.x, direction.y)
		else:
			var prev_cell: Vector2i = snake[maxi(0, i - 1)]
			var next_cell: Vector2i = snake[mini(snake.size() - 1, i + 1)]
			var tangent := Vector3(float(prev_cell.x - next_cell.x), 0, float(prev_cell.y - next_cell.y)).normalized()
			if tangent.length_squared() < 0.5:
				tangent = Vector3(direction.x, 0, direction.y).normalized()
			var cylinder := CylinderMesh.new()
			cylinder.top_radius = 0.44
			cylinder.bottom_radius = 0.44
			cylinder.height = 0.93
			cylinder.radial_segments = 16
			var body_material := _material(Color("#c7d5e2"), 0.6, 0.3)
			body_material.albedo_texture = load("res://assets/tex-snake.png")
			body_material.normal_enabled = true
			body_material.normal_texture = load("res://assets/tex-snake-n.png")
			body_material.normal_scale = 1.4
			body_material.uv1_scale = Vector3(1.0, 0.35, 1.0)
			body_material.emission_enabled = true
			body_material.emission = Color("#22384c")
			body_material.emission_energy_multiplier = 0.25
			var body := _add_mesh(snake_root, cylinder, at + Vector3(0, 0.4, 0), body_material)
			body.basis = Basis(Quaternion(Vector3.UP, tangent))
			var ring := CylinderMesh.new()
			ring.top_radius = 0.465
			ring.bottom_radius = 0.465
			ring.height = 0.18
			ring.radial_segments = 16
			var ring_node := _add_mesh(snake_root, ring, at + Vector3(0, 0.4, 0) - tangent * (TILE * 0.30), _glow_material(Color("#00C864"), 1.0))
			ring_node.basis = Basis(Quaternion(Vector3.UP, tangent))
			var spine := _sphere(snake_root, at + Vector3(0, 0.765, 0), 0.115, _glow_material(Color("#c8ff6b"), 1.0))
			spine.scale = Vector3(1.25, 0.55, 1.0)

func _end_game() -> void:
	state = "game_over"
	paused = false
	_set_screen("game_over")


func _set_screen(screen: String) -> void:
	state = screen
	var showing := screen == "title" or screen == "game_over" or screen == "level_complete"
	overlay.visible = showing
	title_label.visible = showing
	subtitle_label.visible = showing
	pause_label.visible = false
	match screen:
		"title":
			title_label.text = "TRIPLE AAA SNAKE"
			subtitle_label.text = "CLICK OR PRESS ENTER TO START"
		"game_over":
			title_label.text = "GAME OVER"
			subtitle_label.text = "SCORE  %d     •     HIGH SCORE  %d\nCLICK OR PRESS ENTER TO RESTART" % [score, high_score]
		"level_complete":
			title_label.text = "LEVEL COMPLETE"
			subtitle_label.text = "LEVEL 2 INCOMING  •  FASTER.\nCLICK OR PRESS ENTER TO RESTART"


func _update_hud() -> void:
	var total_seconds := int(elapsed)
	var time_text := "%02d:%02d" % [total_seconds / 60, total_seconds % 60]
	time_level_label.text = "TIME   %s     •     LEVEL   %d" % [time_text, level]
	score_high_label.text = "SCORE   %06d       •       HIGH SCORE   %06d" % [score, high_score]
	var percent := int(round(float(apples) * 100.0 / float(APPLES_TO_LEVEL)))
	apples_label.text = "APPLES   %02d/%02d     •     %d%%" % [apples, APPLES_TO_LEVEL, percent]
	progress_fill.size.x = 288.0 * float(apples) / float(APPLES_TO_LEVEL)
	var remaining := maxf(0.0, 4.0 - (elapsed - last_apple_time))
	combo_label.visible = state == "playing" and combo >= 2 and remaining > 0.0
	combo_badge.visible = combo_label.visible
	combo_bar_fill.visible = combo_label.visible
	combo_label.text = "COMBO  x%d     •     %.1fs" % [combo, remaining]
	combo_bar_fill.size.x = 264.0 * remaining / 4.0

func _step_interval() -> float:
	return maxf(0.105, (0.31 - float(apples) * 0.008) / (1.0 if level == 1 else 1.22))


func _cell_to_world(cell: Vector2i) -> Vector3:
	return Vector3(float(cell.x) * TILE, 0, float(cell.y) * TILE)


func _box(size: Vector3) -> BoxMesh:
	var mesh := BoxMesh.new()
	mesh.size = size
	return mesh


func _add_mesh(parent: Node3D, mesh: Mesh, pos: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.position = pos
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(instance)
	return instance


func _material(color: Color, metallic: float, roughness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	return material


func _glow_material(color: Color, energy: float) -> StandardMaterial3D:
	var material := _material(color, 0.5, 0.22)
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = energy
	return material


func _label(text_value: String, font_size: int, color: Color, pos: Vector2, size: Vector2, align: HorizontalAlignment) -> Label:
	var label := Label.new()
	label.text = text_value
	label.position = pos
	label.size = size
	label.horizontal_alignment = align
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 2)
	return label


func _load_high_score() -> void:
	var config := ConfigFile.new()
	if config.load(HIGH_SCORE_PATH) == OK:
		high_score = int(config.get_value("snake", "high_score", 0))


func _save_high_score() -> void:
	var config := ConfigFile.new()
	config.set_value("snake", "high_score", high_score)
	config.save(HIGH_SCORE_PATH)
