# Production 3D Modeling for Godot — Research Dossier

**Date:** 2026-10-16 · **Project context:** A Godot 4.7 game built to AAA-aspirational quality, with a segmented snake as the hero character. Models are authored in Blender, exported as glTF 2.0 (`.glb`), and imported into Godot. This dossier is the production reference for Exercise 1 (models) and for every later modeling exercise: it fixes the export/import contract, the topology, UV, material, and baking standards, the performance budgets, and the rigging decisions that must be made now so animation is not blocked later. It also surveys the 2026 state of AI 3D generation honestly, so the team can decide where generation helps and where hand-authoring or scripted procedural modeling in Blender Python remains the better tool.

**Headline findings**

- glTF 2.0 binary (`.glb`) is Godot's recommended format and the only format in this pipeline that carries PBR materials, skinning, animation, and UV2 together without compromise; OBJ and ad-hoc FBX routes lose one or more of those. Fix scale, pivots, and materials in Blender — the importer will faithfully reproduce whatever you export, including your mistakes.
- Coordinates are not negotiable: Godot is right-handed, Y-up, meters, with `-Z` as camera forward and `+Z` as the front of an oriented asset. Blender is Z-up in the viewport, but its glTF exporter with `+Y Up` enabled performs the conversion. Most "my model faces backwards / is 100× too big" bugs are an unapplied transform or a missed Apply step, not an engine bug.
- Godot generates mesh LODs automatically on scene import via meshoptimizer and switches by screen-space size. Do not bundle `_LOD1` meshes inside the `.glb` expecting Godot to use them as LODs — they arrive as extra stacked meshes. Budget LOD0 yourself; let Godot handle distance.
- Godot, Blender, and glTF all agree on tangent space: MikkTSpace, OpenGL-style normal maps (X+, Y+, Z+). Bake and render in the same tangent space, triangulate before baking, and make every hard edge a UV seam. Mismatched tangents are the single most common cause of normal-map seams.
- Godot's PBR is the metallic/roughness workflow. One ORM texture — R = ambient occlusion, G = roughness, B = metallic — is both the glTF layout and Godot's `StandardMaterial3D` layout. Albedo and emission are sRGB; everything else is linear / Non-Color. Getting that one toggle wrong washes out or darkens an entire character.
- For a grid-based Snake game, a per-segment rigid-mesh design beats a single continuously skinned mesh for gameplay fidelity, determinism, and art control. Model segments now with centered pivots, deliberate overlap geometry, and a consistent taper direction, and either rigging route stays open.
- AI 3D generation in 2026 is genuinely fast for first drafts and organic one-offs — seconds to a minute per asset on hosted tools — but its raw output is routinely 200k–1.9M triangles of dense triangle soup with no edge flow, no segment discipline, and textures baked to the dense mesh. It does not replace retopology, UV, and baking work for a deforming hero.
- The cheapest reliable quality gate is a verify step in Godot itself: instance the imported scene, check scale against a 1 m reference, material channels, triangle count, and LOD behavior before any asset is called done. Editor import is a separate pass from runtime loading — an asset that has not been through the editor import pass can silently show fallback materials.

## Blender → glTF → Godot 4.7 pipeline

### The contract

Godot treats an imported glTF file as a *scene*, not just a mesh. The importer maps glTF concepts to Godot nodes: scene → `Node3D`, node → `Node3D`, mesh → `MeshInstance3D`, skin → `Skeleton3D`, punctual light (`KHR_lights_punctual`) → `Light3D`, camera → `Camera3D`, material → `StandardMaterial3D`, animation → `AnimationPlayer`. The file first loads into an in-memory `GLTFState`, then `ResourceImporterScene` applies the Import dock and Advanced Import Settings and saves a Godot scene (`.tscn`/`.scn`) that the game actually runs. Two consequences follow. First, you never hand-edit the generated imported scene to fix an asset — you fix the source in Blender and re-export, or you build an inherited/wrapper scene on top of the import. Second, editor import and runtime import are different paths: runtime `GLTFDocument.append_from_file()` → `generate_scene()` skips the editor layer (name-suffix handling, material extraction, LOD generation). What you test in the editor is not byte-identical to what a runtime loader produces ([Godot documentation — Importing 3D scenes](https://docs.godotengine.org/en/4.1/tutorials/assets_pipeline/importing_scenes.html); [StraySpark — Meshy and Tripo Models in Godot 4](https://www.strayspark.studio/blog/meshy-tripo-to-godot-4-gltf-lod-normal-maps)).

Godot 4.7 continues to list glTF 2.0 as the recommended format alongside `.blend`, Collada, OBJ, and FBX. FBX now uses ufbx by default (since 4.3), and `.blend` import works by calling an installed Blender (3.0+, 3.5+ recommended) to run the glTF exporter transparently. `.blend` import is convenient for solo iteration but requires every team member and CI machine to have a compatible Blender, and it is unavailable in the Android and web editors. For a production pipeline — and for scripted, reproducible Exercise 1 builds — explicit `.glb` export is the right default: one self-contained binary, textures embedded, diffable only by hash, and identical on every machine.

### Coordinate and scale conventions

Godot: right-handed, Y-up, 1 unit = 1 meter. Camera forward is `-Z`; therefore `+Z` is back for a camera. For an *oriented asset* (a character), the convention inverts: the asset's front faces `+Z`, its rear is `-Z`, its left is `+X`, its right is `-X` when viewed from the front. When you call `look_at()` on such an asset in code, use `use_model_front` and the `Vector3.MODEL_*` constants rather than assuming camera conventions.

Blender: right-handed, Z-up in the viewport, also 1 unit = 1 meter by default (Unit Scale 1.0, Metric). In Blender terms, an asset's front is `-Y` and its rear is `+Y`; north is `+Y`, south is `-Y` after conversion. The glTF exporter bridges the two systems. With **Transform → +Y Up** enabled (leave it enabled — always), Blender's Z becomes glTF/Godot Y, Blender's `-Y` (front) becomes Godot `+Z` (front), and Blender's X stays X (with handedness handled by the exporter's conversion). Practical rules:

1. Model the snake facing `-Y` in Blender (head pointing toward the bottom of the Top view). It will face `+Z` in Godot, which is correct model-front orientation.
2. Set real-world size in Blender and check it in the N-panel Dimensions. A body segment intended to occupy one grid cell of, say, 1.0 m should measure ~1.0 m in Blender, not 1 cm or 100 m.
3. Apply transforms before export: select all export objects, `Ctrl+A → All Transforms` (location, rotation, scale). Object scale must read 1, 1, 1. Unapplied scale is the top cause of "explodes in Godot" and of skinning that shears under animation.
4. Keep the character's logical origin at the world origin for the hero export, or at the documented pivot (see §8). Do not export a character sitting 37 m from the origin because that is where you happened to model it.

Godot's Import dock offers **Root Scale** and **Apply Root Scale** as a patch for wrong size. Treat them as an emergency shim for third-party assets, never as the pipeline. Fix size in Blender so every instance, collision shape, and navigation query agrees.

### Blender glTF exporter settings that matter

Use `File → Export → glTF 2.0 (.glb/.gltf)`, Format: **glTF Binary (.glb)**. The settings below are the production preset for this project. Where a setting is asset-dependent, the rule is stated.

**Include**
- *Selected Objects:* On when exporting a curated set (hero + armature); off only for whole-scene environment exports. Being explicit prevents stray helper meshes, lights, and cameras from shipping.
- *Custom Properties:* On if you use custom properties for gameplay metadata; otherwise harmless.
- *Cameras / Punctual Lights:* Off for character/props. Design lighting in Godot, not Blender, for final look.

**Transform**
- *+Y Up:* **On, always.** Turning it off is the classic way to get a character lying on its back in Godot.

**Geometry / Mesh**
- *Apply Modifiers:* **On** for the final game mesh — with one critical caveat. The exporter option applies modifiers at export time without destroying your working file, which is what you want for Mirror, Subdivision Surface (at the chosen render level), Triangulate, and similar. It historically also interacts with the Armature modifier: current Blender exporter versions handle the armature case correctly (they do not bake the current pose into the mesh), but you must verify on your Blender version with a posed test export. If you use the older workflow of manually applying modifiers in the stack, **never manually apply the Armature modifier** on the export copy — that destroys skinning. Work on a duplicate collection/file for any destructive apply.
- *UVs:* On. *Normals:* On. *Tangents:* On if your baker produced MikkTSpace tangents and you want them preserved verbatim; otherwise leave off and enable Godot's **Ensure Tangents** so Godot generates MikkTSpace tangents on import. Either path is valid — what is invalid is a baker, exporter, and engine each using a different tangent basis (see §6). Pick one per project and document it. For this project: export tangents from Blender when a normal map is present.
- *Vertex Colors:* On only if the material actually uses them (e.g., tint masks, ID colors). Otherwise off to save size.
- *Materials:* **Export** (not Placeholder, not None) for hero assets. *Images:* Automatic; Compression off for source exports (Godot recompresses on import; double-compressing textures in the `.glb` only loses quality).

**Animation**
- *Animations:* On for rigged assets. Decide one source of truth: **Actions** or **NLA Strips**. For multiple named clips, push each Action down to an NLA strip (or stash it) and export via NLA so clip names in Godot match strip names exactly. Uncheck "export all actions" style catch-alls when you have curated NLA strips, or you will import dozens of test actions. Give every Action a Fake User (shield icon in the Action Editor) so Blender does not garbage-collect unassigned actions on save.
- *Always Sample Animations / Sampling Rate:* Sampling bakes constraints and complex rigs to keyframes. Leave sampling on for any rig that uses constraints you intend to bake; set the sampling rate to match your target (commonly every frame at the scene frame rate for hero clips; higher step values shrink files for simple loops at some fidelity cost). Bake IK, constraints, and curve-following to keyframes before export — glTF carries sampled bone transforms, not Blender constraint graphs. Do not animate with delta transforms.
- *Shape Keys:* Export if the design uses morph targets (e.g., snake jaw, blink). Note the Godot documentation warning: if the model contains blend shapes, set **Data → Armature → Export Deformation Bones Only** to Enabled, or non-deforming bones exported alongside morphs cause incorrect shading.

**Skinning**
- *Skinning:* On for rigged meshes. *Include All Bone Influences:* Off by default — glTF/Godot skinning is typically evaluated with up to 4 influences per vertex in the standard path; exporting unlimited influences bloats data and can change deformation. Paint weights with a 4-influence limit in mind and normalize. Only enable all-influences when debugging a rig that inexplicably deforms differently in Godot, as a diagnostic.

**What does not survive export:** Most of Blender's procedural node graph does not translate to glTF. Only the Principled BSDF inputs that map to the glTF metallic/roughness core (plus supported extensions — see §5) are exported as a material definition; everything else must be baked to textures. Geometry Nodes graphs, drivers, constraints, and modifiers that are not applied (or not apply-at-export) likewise do not transfer as live systems — they transfer as their evaluated mesh result, or not at all. Plan on baking, not on node-for-node parity.

### Godot import settings

After copying the `.glb` (and any external textures, if you chose separate-files export) into the project, focus the Godot editor so the import pass runs, then select the file in the FileSystem dock and review the Import dock:

- **Root Type / Root Name:** Leave Root Type as `Node3D` (or a Node3D-derived type) so the imported scene can be positioned in 3D. Root Name matters little when instancing, because the instance root takes the filename, but keep it clean anyway.
- **Apply Root Scale / Root Scale:** As above — leave at 1.0 for pipeline assets.
- **Meshes → Ensure Tangents:** On if the source lacks tangents. No effect if tangents were exported.
- **Meshes → Generate LODs:** On by default for scenes; see §7 for when to disable (notably some skinned meshes).
- **Meshes → Light Baking / UV2:** Set to *Static Lightmaps* only for assets that participate in LightmapGI baking; Godot then generates UV2 on import. Dynamic characters (the snake) should not pay for lightmap UV2.
- **Animation → Import / Storage / FPS / Trimming:** Enable animation import for rigged assets. Use *Separate Animation Files* / animation library extraction only if the project's animation workflow calls for it; the default (animations inside the imported scene, played by the generated `AnimationPlayer`) is correct for Exercise 1 verification.
- **Materials → Extraction:** For hero assets, consider extracting materials to external `.tres` files (Advanced Import Settings → Materials → Extract) so materials can be versioned, overridden, and shared without re-importing the mesh. For rapid iteration, embedded materials are fine; for production, extracted materials are easier to diff and to patch without touching geometry.
- **Advanced Import Settings (double-click the scene):** Per-node / per-mesh / per-material overrides: generate physics bodies, set light baking mode, disable LOD per mesh, extract materials/meshes. This dialog — not the generated scene — is where per-object import customization lives.

**Import hints (name suffixes from Blender):** Godot reads suffixes on object names at import. The ones that matter here: `-col` (keep mesh + add trimesh/concave static collision from the same geometry), `-convcol` (convex collision), `-colonly` (collision only, mesh removed, static), `-convcolonly` (convex collision only), `-noimp` (do not import this object), and light/shadow-related suffixes documented in the import docs. For the snake, prefer primitive collision (box/capsule shapes sized to the grid) authored in Godot over trimesh collision generated from a hero mesh: trimesh collision from a 30k-triangle segment is expensive and, per Godot's collision documentation, concave shapes only work on static bodies anyway. Generate any auto-collision from the *budgeted* mesh, never from a raw sculpt or AI output.

**Naming discipline:** Use one convention and enforce it in the export script: lowercase `snake_case` for files (`snake_head.glb`, `snake_segment.glb`, `snake_tail.glb`), PascalCase or matching names for nodes inside Blender so Godot node paths are predictable (`Head`, `Segment`, `Tail`, `Skeleton3D`). Animation clips get verb-noun lowercase names (`idle_sway`, `turn_left`, `eat`). The import script / pipeline addons that key off names will silently do nothing if names drift — consistency is a functional requirement, not tidiness.

### Common failure modes and fixes

| Symptom | Likely cause | Fix |
|---|---|---|
| Model 100× too large/small | Blender unit scale ≠ 1.0, or unapplied object scale | Set Unit Scale 1.0, size in meters, `Ctrl+A` apply, re-export. Do not patch with Root Scale except as a stopgap. |
| Model lying down / facing backwards | `+Y Up` off, or modeled facing `+Y` in Blender | Enable `+Y Up`; model front toward `-Y` in Blender. |
| Only half a character exports | Mirror modifier not applied at export | Enable Apply Modifiers at export (on a copy if destructive). |
| Mesh exports posed, won't animate | Armature modifier manually applied, or pose not rest | Reset skeleton to rest/T-pose before export; never apply Armature on the skinned copy. |
| Animations missing / wrong clips | Actions not stashed/pushed to NLA, no Fake User, wrong animation mode | Stash/push actions, set Fake User, export the curated NLA set, verify clip list in Godot's AnimationPlayer. |
| Shading looks faceted / wrong | Backface culling mismatch; normals not exported; non-deforming bones with morphs | Enable Backface Culling in Blender material if Godot material should cull (Godot otherwise imports cull Disabled, costing fill rate); export normals; enable Deformation Bones Only when morphs exist. |
| Normal map bumps read as dents | DirectX (Y−) map in an OpenGL (Y+) pipeline | Use OpenGL-style maps; or select the texture in Godot → Import → Process → Normal Map Invert Y → Reimport. |
| Colors washed out / too dark | sRGB flag wrong on a texture (see §5) | Albedo/emission = sRGB; normal/roughness/metallic/AO/ORM = linear (Non-Color in Blender). |
| Pink / flat grey fallback material in a fresh checkout or headless run | **The editor import pass has not run on the new assets.** Imported resources (`.import` files and the `.godot/imported/` cache) are generated by the editor. Dropping a `.glb` + textures into a project folder and running the game (or a headless runtime load) without first opening/focusing the editor — or running `godot --headless --editor --import --quit` in CI — leaves Godot without converted textures/materials, and it silently falls back to a default material. | Always run the editor import pass after adding assets: open the project in the editor and let it finish importing, or in automation run the headless editor import command and check for errors before launching the game. Commit the `.import` sidecar files to version control (they are generated metadata, but they record the intended import settings); never hand-edit them. Restart the editor after changing certain import modes (documented for OBJ-as-Scene). |
| Imported scene updates don't appear | Re-exported while a different scene is open, or editor not focused | Focus the editor to trigger reimport; open the scene that instances the asset when using pipeline addons that require it; use Reimport explicitly. |
| Jagged triangulation / shading tears | N-gons triangulated differently by Blender, baker, and Godot | Triangulate before export (Triangulate modifier + Apply Modifiers, or exporter triangulate option) and bake from the triangulated mesh, so every tool sees the same triangles. |
| LOD levels stacked on top of each other | `_LOD` meshes bundled in the `.glb` | Remove bundled LOD meshes; use Godot auto-LOD or visibility-range HLOD (see §7). |

A note on direct `.blend` import for completeness: it uses the same glTF exporter under the hood, so all exporter guidance above applies, but you lose explicit control over the export preset per asset and you couple every checkout to a local Blender install. Use it for prototyping if you like; ship `.glb`.


## Topology & modeling technique

Topology is the decision you cannot patch later with a texture. It determines how a mesh deforms, how it bakes, how it LODs, and how painful every revision is. The standards below are written for real-time Godot delivery, not for offline rendering.

### First principles

- **Model in quads, export in triangles.** Quad-dominant topology is for *you* — clean subdivision, predictable edge loops, easy selection and revision. GPUs render triangles, and Godot will triangulate on import if you do not. Triangulate deliberately before export/bake so Blender, the baker, and Godot all split quads on the same diagonal. N-gons are not acceptable at export: their triangulation is implementation-defined and a common source of shading tears.
- **Spend polygons on the silhouette.** A polygon that does not change the outline, the deformation, or the shadow is wasted. Flat areas get few polygons; curvature, joints, and the silhouette get density. Interior detail that does not move the outline belongs in the normal map, not in geometry.
- **Clean geometry, always:** no non-manifold edges, no zero-area faces, no duplicate vertices (Merge by Distance as a deliberate step, not a ritual), no interior faces, no loose vertices/edges, normals outward and consistent. Run Blender's 3D Print Toolbox / mesh analysis or an export validator before handoff. AI-generated and boolean-heavy meshes fail this checklist by default (see §9).
- **Even density where it deforms, economical density where it does not.** A deforming region with wildly uneven polygon sizes twists unevenly and bakes unevenly.

### Edge flow for organic forms

For organic characters — the snake included — edge flow follows anatomy and deformation, not the UV grid:

- Loops run *around* the form (circumferential loops around the snake's body tube) and *along* the form (longitudinal lines from head to tail). Circumferential loops are what let a tube bend without collapsing: each bend needs at least 3 loops around the joint region (one at the joint, one on each side to hold volume), the same rule as elbows and fingers on a humanoid.
- Flow follows muscle/fat movement and the direction of stretch. On the snake head, loops radiate around the jaw hinge and the eye orbits; poles (vertices where 3 or 5+ edges meet) are placed on flat, low-deformation areas, never on a joint crease or the center of a highlight. A 5-pole is normal and necessary; a pole in the wrong place produces a pinching star visible in every specular highlight.
- Avoid long, thin triangles on deforming organic meshes — they shade badly under animation and interpolate weights poorly. Slightly higher, even quad density beats a "clever" low count with slivers.
- Keep a consistent spiral/segment rhythm on a tube character: if body segments are meant to read as repeating units (scutes/scales), the topology should repeat with them, so one segment's UVs, weights, and LOD behavior predict the next.

### Subdivision-surface strategy

Subdivision Surface (Subsurf / Catmull-Clark) is an *authoring* tool, not a delivery format. Godot receives triangles, not a live subdivision surface.

- Model the low (cage) mesh with Subsurf preview at level 1–2 to judge the smoothed result. Supporting loops (extra loops close to a crease) control sharpness under subdivision; crease weights are the alternative, but support loops survive export/bake workflows more predictably.
- Decide the delivery resolution explicitly: Apply Subsurf at a chosen level for the high-poly bake source; keep the un-subdivided (or level-1) mesh as the game low-poly if its silhouette suffices, retopologized if it does not. Never ship a level-3+ subdivided mesh as the game mesh because "it looked smooth in Blender" — you are shipping hundreds of thousands of triangles to do a normal map's job.
- For the snake, a practical pattern: sculpt/model high at Subsurf 2–3 for the bake source (scales, head detail), game mesh at a hand-tuned density (see budgets below) with detail recovered via the normal bake.

### Where bevels earn their cost

A bevel is never free — it adds loops, complicates UVs, and multiplies at LOD time — but a hard 90° edge is also never correct at AAA-aspirational quality: real edges catch a highlight, razor edges alias, and an unbeveled low-poly bakes a gradient-prone normal map.

- Bevel edges that catch light and sit near the camera: hero prop rims, armor plates, weapon edges, architectural trim. A 2–3 segment bevel on the low-poly, baked against the high-poly, gives a believable highlight roll.
- Do not bevel everything. Small background props read fine with a normal-map-only edge treatment (bake a beveled high-poly onto an unbeveled low-poly). Organic forms (the snake's body) rarely want explicit bevels at all — their "edge treatment" is smooth shading and the bake.
- Hard-surface rule of thumb: if an angle change is > ~60° and the edge is silhouette-adjacent, give it geometry (support bevel + hard edge + UV seam). If it is interior and shallow, let the normal map carry it.

### Hard-surface vs organic

| | Organic (snake, creatures, cloth-like forms) | Hard-surface (props, weapons, architecture) |
|---|---|---|
| Flow priority | Deformation loops, anatomy | Planar faces, clean booleans cleaned up by hand, support loops |
| Shading | Smooth shading throughout; hard edges rare | Hard edges / custom (weighted) normals deliberate; pick one strategy per asset |
| Sculpting | Primary authoring method; retopo expected | Kitbash + bevel modeling primary; sculpt for damage/wear pass only |
| Bake risk | Stretch / weight interpolation | Gradient bakes on large flat faces without support geometry or custom normals |
| Typical failure | Pole pinching, volume loss at bends | Boolean residue, n-gons, shading gradients |

For hard-surface baking specifically, choose per asset: (a) hard edges at UV seams on large angles, or (b) weighted/custom normals on a beveled low-poly. Mixing both accidentally on one asset produces the classic "why does this flat panel shade like a balloon" bug.

### Polycount budgeting

Godot does not publish official triangle budgets — correctly, because the right number depends on renderer (Forward+ vs Mobile vs Compatibility), camera distance, instance count, and what else is on screen. The budgets below are production starting points consistent with common Godot 4 preset guidance (hero ~30,000 triangles, prop ~10,000, environment piece ~20,000 for desktop; roughly half or less for web/mobile presets) ([StraySpark — Meshy and Tripo Models in Godot 4](https://www.strayspark.studio/blog/meshy-tripo-to-godot-4-gltf-lod-normal-maps)). Profile against them; they are budgets to argue with measurements, not laws.

- **Hero character (the snake, whole assembled character on screen):** 25,000–50,000 triangles for LOD0 on desktop Forward+ is a defensible AAA-aspirational target for a single hero with 2K textures, provided the rest of the scene is budgeted. Structure it as reusable parts (see §8): e.g., head 6,000–10,000 (it gets close-ups: eyes, jaw, tongue fork), body segment 800–1,500 per segment design instanced/repeated, tail 1,500–3,000. A design that spends 30k per body segment times 20 segments is not a budget, it is an accident.
- **Secondary characters / larger enemies:** 10,000–25,000.
- **Hero props (held/inspected):** 5,000–15,000. **Background props:** 500–5,000 depending on size and count; a prop scattered 50× at 10k each costs more than the hero — instance count multiplies the budget.
- **Environment:** budget per *view*, not per asset: set a total visible-triangle target for your worst camera (e.g., 1–3M visible triangles for desktop Forward+ at 1080p is a workable starting envelope for a stylized-realistic scene; measure on target hardware) and allocate across environment pieces, then enforce per-asset caps from it.

Count triangles, not "polys" (quads hide a factor of ~2). Report LOD0 triangle count for every delivered asset in the handoff notes.

### Retopology expectations

Retopology (retopo) is not optional polish for a sculpted or generated hero — it *is* the game mesh. Expectations for this project:

- Every sculpt (Blender Sculpt Mode, or any external sculpt) and every AI-generated mesh used beyond a blockout goes through retopo before UV/bake. Blender-native options: manual retopo over a Shrinkwrap-projected new mesh (the hero standard), QuadriFlow remesh (good for organic mid-detail, requires near-manifold input), and Voxel Remesh (fast blockout cleanup; destroys deliberate flow — never the final deforming mesh). Instant Meshes / Quad Remesher (external) are acceptable tools if available; the output standard is the same regardless of tool.
- Retopo output must pass the topology checklist above, meet the triangle budget within ±10%, deform-test cleanly (bend the snake through its tightest gameplay turn with no collapse), and hold the high-poly silhouette within an agreed tolerance when overlaid.
- Static background props may use decimation instead of hand retopo *if* they do not deform, are not hero-close, and their decimated UV/bake still passes. That exception is per-asset and recorded, not a pipeline default.

## UV unwrapping

UVs are the contract between geometry and every texture you will ever bake or paint. A bad unwrap cannot be fixed by a higher texture resolution — it just renders the defect at higher fidelity.

### Seam placement strategy

- Seams go where the eye does not: under the snake's belly (the ventral side, which faces the ground/grid), along the inside of curves, under overlapping scales/plates, and at natural material breaks (head-to-neck transition hidden under a collar-like scale ring). On a tube character, one longitudinal seam along the belly centerline plus ring seams at segment boundaries is the natural layout.
- **Every hard edge must be a UV seam.** The converse is not required (a seam need not be a hard edge). A hard edge without a seam forces the baker to average across a discontinuity and produces visible gradients/seams in the normal bake.
- Seams also follow deformation: do not run a seam across the middle of a tight bend's stretch zone if it can run along it instead; stretching distorts texel density exactly where the seam makes distortion most visible.
- Minimize seam *count* subject to the above: each seam duplicates vertices and wastes padding. A snake tube can unwrap as a clean cylinder with one seam — take the win.

### Texel density targets

Texel density (texture pixels per world unit) is what makes two different assets look like they belong in the same game. Set one project target and hold it within ~±20% across assets that share the screen; faces/hero features may deliberately run higher, distant trim lower, but the *base* density is a project constant.

Working numbers for this project (desktop, Forward+):

| Context | Target density | What it means in practice |
|---|---|---|
| Hero character at 1080p gameplay distance | **1024 px/m** | A 1.8 m snake section filling much of the screen still resolves scale detail; head on a 2048² map |
| Hero character, 4K / close-up inspection | **2048 px/m** for the head/hero element only | Achieved by giving the head its own larger UV share or its own texture set, not by raising the whole character to 4K maps |
| Background props | **512 px/m** | Standard mid-ground density; 512–1024 px textures for most props |
| Large environment surfaces | 256–512 px/m unique + tiling detail | Unique density is lower because tiling/detail maps add perceived resolution |

These align with common industry guidance of ~512 px/m for background props and ~1024 px/m for hero assets ([RebusFarm — Texel Density Explained](https://static.rebusfarm.net/fr/fr-blog/texel-density-basics-every-artist-should-know)). The underlying logic is screen coverage: at 1920×1080, an object occupying half the screen height shows roughly 540 screen pixels for its visible height; if its texture provides far fewer texels than that, it blurs no matter how good the art is, and far more than that is memory spent on detail the display cannot show — until the camera moves closer, which is why hero/close-up assets get the higher tier. Use Blender's Texel Density Checker add-on (or equivalent) to measure, not eyeballing: set the target, select all islands, apply, then hand-adjust the intentional exceptions (head up, belly down).

Additional rules:

- **Straighten and align** cylindrical/island shells where possible (the snake body unwraps to near-rectangles) — straight islands pack tighter and tile/repeat cleanly along the body.
- **Padding:** leave at least 8–16 px padding between islands at 2048² (scale proportionally: 4–8 px at 1024²) to survive mip bleeding. Bake with matching extrusion/padding and generate padding/dilation in the bake, not by smearing afterward.
- **0–1 space discipline:** game UVs live in the 0–1 tile. No island crosses a tile boundary for a single-tile asset; overlapping islands only where mirroring/repetition is intentional (below).

### Packing

Pack for occupancy without destroying the density target: aim for 70–85% UV occupancy on hero assets (100% is unattainable with organic island shapes; below ~60% you are wasting a resolution tier). Rotate islands to fit (allow 90° rotations on organic shells where grain direction does not matter; restrict rotation on the snake's dorsal pattern if scale direction must flow head-to-tail — direction matters for anisotropic-looking scale painting). Use a packer (Blender's Pack Islands with margin set from the padding rule, or UVPackmaster if available) *after* density is set, with "lock" on any island whose scale is an intentional exception.

### UDIM vs single tile for games

UDIM (multiple 1001+ tiles, one texture set per tile) is a film/VFX workflow. For real-time Godot delivery, **use a single 0–1 tile per texture set**. Reasons: glTF core materials reference one texture per map slot; Godot's `StandardMaterial3D` samples one UV space per map; UDIM sets multiply material/draw complexity and are not natively resolved by the glTF importer into a single Godot material. If a hero needs more resolution than one 2048² (or 4096²) map provides, split by *material/part* — head gets its own mesh/material/texture set, body gets another — which also gives independent LOD, material, and culling control. That is the game equivalent of UDIM, and it maps cleanly through glTF.

For the snake specifically: **Texture Set A — Head** (2048², high density, unique paint: eyes, mouth interior, pattern). **Texture Set B — Body segment** (1024² or 2048², designed to repeat along the body; see mirroring/repeat below). **Texture Set C — Tail** (1024², may share the body set if the taper UVs allow). Two to three materials/draw calls for the hero is the right order of magnitude (see §7).

### Mirroring trade-offs

Mirroring (overlapping left/right UVs so one texture serves both sides) halves texture cost and guarantees symmetry — valuable for props, vehicles, and architecture. For the snake:

- **Body cross-section:** mirroring dorsal-to-ventral or left-to-right across the body tube is attractive for a repeating segment: one scale pattern serves the whole circumference's repeat unit. Risk: visible repetition and a perfectly symmetric pattern reads artificial on an organic hero; a snake's dorsal pattern is naturally somewhat irregular. Mitigation: mirror the *geometry/UV base* for density, then break symmetry in the albedo with a second, non-mirrored detail/pattern pass or vertex-color variation per segment instance.
- **Head:** do not mirror the head's unique paint across the centerline if the design calls for asymmetric markings, scars, or pattern identity. Biped-style "mirrored face" artifacts (identical nostril dirt on both sides) are a known realism tell. Mirror the head *geometry* for modeling speed if you like, then unwrap it uniquely for paint.
- Mirrored UVs with tangent-space normal maps require care: mirrored halves share tangent space with flipped handedness, which MikkTSpace handles via the tangent sign (w component) *if* tangents are exported/handled correctly. This is a solved problem in the Blender→glTF→Godot MikkTSpace chain, but it is also a classic place for one side of a character to shade inverted when a tool in the chain drops the tangent sign. Test mirrored normal maps in Godot early, on the actual segment, before committing the whole body to the scheme.

## PBR material authoring

Godot 4's `StandardMaterial3D` is a metallic/roughness PBR material, closely aligned with the glTF 2.0 core material model. That alignment is the good news: a correctly authored Principled BSDF material in Blender exports to a materially equivalent Godot material without a translation layer inventing values. The bad news is that "correctly authored" has a precise meaning, and every shortcut shows.

### The metallic/roughness workflow Godot expects

- **Metallic** is binary in reality and should be near-binary in your maps: 0.0 = dielectric (skin, scale keratin, wood, plastic, stone), 1.0 = metal. Intermediate values exist only in thin transition pixels (rust edges, worn paint over metal). A snake is a dielectric: metallic 0.0 across the body. Do not raise metallic to "make it shinier" — shininess is roughness's job. Metals tint their reflections with the albedo color; dielectrics reflect ~4% white-ish (F0 0.04) and show their albedo in diffuse. Getting metallic wrong is immediately visible as black-crushing or plastic-looking metal.
- **Roughness** carries most of the material storytelling: 0.0 = mirror, 1.0 = fully matte. Snake dorsal scales might sit at 0.45–0.65 roughness with per-scale variation, the belly scutes slightly smoother (0.35–0.5, more ground contact polish), eyes near 0.05–0.15 with clearcoat-like gloss (approximated in the core workflow; see extensions below), mouth interior higher roughness and darker albedo. Author roughness *variation* — a flat roughness value across a whole character is the fastest route to a "plastic toy" read.
- **Specular / F0:** Godot exposes specular controls on `StandardMaterial3D`; glTF core folds this into the metallic/roughness model with a fixed dielectric F0, extended by `KHR_materials_specular` / `ior` where supported (see "what survives export" below). For Exercise 1, stay in the core model.

### The texture set

Per texture set (see §4), deliver:

| Map | Contents | Resolution (hero snake) | Color space |
|---|---|---|---|
| Albedo / Base Color | Diffuse color only — **no baked lighting, no AO, no specular highlights** | Head 2048², Body 2048² (repeating set) or 1024² if density target met, Tail 1024² | **sRGB** |
| Normal | Tangent-space detail (see §6) | Same as albedo per set | **Linear / Non-Color** |
| Roughness | Greyscale: white = rough | Same, or half-res if variation is low-frequency | Linear / Non-Color |
| Metallic | Greyscale: white = metal (snake: near-black everywhere) | Can be packed (ORM); standalone may be omitted for a pure dielectric with scalar 0.0 | Linear / Non-Color |
| AO (ambient occlusion) | Baked crevice/contact darkening | Packed in ORM R; also usable as glTF occlusion texture | Linear / Non-Color |
| Emission | Self-illumination color × mask (e.g., glowing pattern variant, eye glint is *not* emission) | Only if the design uses it; same res as albedo when present | **sRGB** (color), mask behavior per material setup |
| Height (optional) | For Godot parallax (`heightmap` / POM in StandardMaterial3D) or as bake source | Rarely shipped on a character; prefer normal | Linear / Non-Color |

Texture budget check: one 2048² texture set with albedo (BC7/sRGB) + normal (BC5) + ORM (BC7/linear) is roughly 16 MB + 8 MB + 16 MB of GPU memory with mips (order of magnitude; exact size depends on Godot's import compression — VRAM / BPTC on desktop). Two to three sets for the hero is affordable; ten sets is a different game. Godot texture import: leave **Mipmaps → Generate** on for 3D textures (required for correct distance filtering and for LOD of *texture* cost), set Compress Mode to VRAM Compressed for production textures, and confirm the importer detects normal maps correctly (Import As / Normal Map mode on Detect, so a texture used as a normal map gets normal-appropriate compression).

### Color space rules — the one-toggle bug class

- In **Blender**, every Image Texture node declares a color space. Albedo and emission color textures: **sRGB**. Normal, roughness, metallic, AO, height, and any mask/data texture: **Non-Color**. Blender's Principled connections assume this; the glTF exporter writes the glTF texture `colorSpace` semantics from the slot (baseColor/emissive = sRGB; all data maps = linear), not from your intentions.
- In **Godot**, imported textures carry an sRGB flag derived from the glTF/import context. A data map incorrectly flagged sRGB gets gamma-expanded on sample and produces washed-out roughness and broken normals; an albedo flagged linear renders dark and muddy. When a material "looks wrong in Godot but right in Blender," check color space flags before touching any slider.
- Vertex colors follow the same rule: treat them as linear data or sRGB color deliberately, not accidentally — Godot notes vertex color brightness is clamped to 1.0 on import for some formats, so do not encode HDR data in vertex colors.

### Channel packing (ORM)

Pack three single-channel data maps into one RGB texture to cut texture fetches and memory: **R = Ambient occlusion, G = Roughness, B = Metallic** — abbreviated ORM. This is simultaneously the glTF convention (glTF's `occlusionTexture` reads R; `metallicRoughnessTexture` reads G = roughness, B = metallic) and Godot's convention: `BaseMaterial3D`'s ORM handling reads AO from red, roughness from green, metallic from blue, alpha ignored. On glTF import, Godot 4.7 builds a `StandardMaterial3D` pointing its AO/roughness/metallic slots at the packed image with the corresponding channel selectors — no manual wiring — or you can use `ORMMaterial3D` by hand with the packed texture in a single slot ([StraySpark — ORM in Godot 4](https://www.strayspark.studio/blog/meshy-tripo-to-godot-4-gltf-lod-normal-maps)).

Packing rules: pack only maps that share UVs and resolution (true by construction within a texture set); pack at the highest resolution any constituent needs (roughness detail usually drives it); keep albedo and normal unpacked (they need their own formats/compression — BC7 sRGB vs BC5 — and normal green channel precision matters). In Blender, pack with a Combine/Separate color step into a single baked image, or pack in your texturing tool; in the Principled setup for export, route AO through the exporter's expected path (the glTF Material Output / occlusion setup) so the exporter writes it as the glTF occlusion texture rather than baking AO into albedo. **Never bake AO into albedo** for a PBR asset: Godot will light it again and double-darken every crevice, and the asset becomes unusable under different lighting.

### Authoring in Blender — and what survives glTF export

Author hero materials as: Principled BSDF with texture inputs for Base Color, Roughness, Metallic, Normal (via a Normal Map node, Tangent space), and Emission where designed; procedural variation (Noise, Musgrave, Voronoi for scale patterning, ColorRamp shaping, bump from procedural height) is welcome **as a bake source**. The export reality:

**Survives as material parameters (glTF core):** base color (factor + texture), metallic factor + texture, roughness factor + texture, normal texture (+ scale), occlusion texture (+ strength), emissive factor + texture, alpha mode/cutoff, double-sided flag. These map directly to `StandardMaterial3D`.

**Survives via KHR extensions (support varies — verify per target Godot version before relying on them):** `KHR_materials_clearcoat` (clearcoat layer — tempting for snake eyes/wet scales), `KHR_materials_transmission` (translucent volumes), `KHR_materials_ior` / `specular`, `KHR_materials_sheen`, `KHR_materials_emissive_strength`, `KHR_texture_transform` (per-texture UV offset/scale/rotation). Godot's glTF importer supports a subset of material extensions and the subset grows by version; treat any extension beyond the core as an explicit test item: export a one-material test asset, import into the pinned Godot 4.7 build, and record the result. If an extension is dropped on import, the fallback is to approximate in the core model or implement the effect as a Godot shader material on an extracted material — a deliberate decision, not a surprise discovered at integration.

**Does not survive:** arbitrary shader node graphs (mix shaders, custom procedural chains feeding Principled inputs without baking, Blender-only nodes like Fresnel/Layer Weight tricks used as logic), Cycles-only light behavior, and compositor effects. Anything procedural that matters must be **baked to the texture set** before export. This is also the versioning win: a baked texture set renders identically in Blender's material preview (with the baked maps connected), in glTF viewers, and in Godot.

**Snake material recipe (Exercise 1 starting point):** One Principled material per texture set. Albedo: base dorsal color with a procedural scale pattern (Voronoi/brick-like cells shaped and distorted, baked) modulated by painted variation; belly lighter/desaturated via the UV region (ventral islands occupy a known UV band, so a UV-coordinate mask separates dorsal/ventral treatment cleanly). Roughness: 0.5 base, ±0.15 per-scale variation from the same pattern source, belly 0.4. Metallic: 0.0 scalar, no texture needed standalone (ORM B channel = black). Normal: baked from high-poly scale sculpt (§6), plus a fine procedural bump→normal contribution for micro-texture if the bake resolution leaves headroom. Eyes: separate small material — albedo dark, roughness 0.08, metallic 0.0, clearcoat *only if* the extension test passes, otherwise fake the wet highlight with low roughness + environment lighting.

## Normal maps: baking high → low

A normal map stores, per texel, a perturbed surface normal in tangent space, letting a low-poly mesh shade like a higher-poly one. It is the highest-leverage texture in the set — and the one with the most ways to fail silently.

### The bake workflow

1. **High-poly:** the sculpt / Subsurf-applied mesh with all silhouette-adjacent and surface detail (individual scales, head anatomy, scute ridges). No UVs required on the high.
2. **Low-poly:** the final game mesh — retopologized, triangulated, UV-unwrapped (§4), with final smoothing/hard edges set. *Bake from the exact triangulated mesh you will export.* Baking from quads and exporting triangles re-splits faces and invalidates the bake at every split.
3. **Baker settings (Blender Cycles bake, or Marmoset/Substance/xNormal if in the pipeline):** Bake Type = Normal, Tangent space; select high → low ("Selected to Active"); set Ray Distance / cage as below; margin (padding) ≥ the UV padding rule (16 px at 2048²); bake at final resolution or 2× and downsample for antialiasing (supersampling a bake cleans diagonal/stepping artifacts measurably).
4. Simultaneously bake AO (high→low, plus low self-occlusion), and bake albedo/roughness variation from high-poly polypaint/procedural sources where applicable, all against the same UVs and cage so maps register pixel-perfectly.

### Cage and ray distance

The baker projects rays from (or toward) the low-poly surface to capture the high-poly. Two controls decide success:

- **Cage:** an inflated copy of the low-poly that encloses the high-poly everywhere. Use a cage whenever the high deviates significantly from the low (deep scale relief, jaw interior). In Blender: create the cage object (low-poly copy, fattened along normals — `Alt+S` / Displace) and assign it in the bake Cage field. A cage that intersects the high anywhere produces a hard bake artifact at that spot; a cage too far away captures neighboring geometry (a scale capturing the adjacent scale's normal — "projection skew / wavy normals" on flat-ish regions).
- **Ray Distance / Extrusion (no-cage mode):** Blender's "Extrusion" (start distance along the normal) + "Max Ray Distance". Start small: extrusion just enough to clear the low surface, max distance just enough to reach the deepest high detail (for scale relief on a ~1 m segment, start at 0.01–0.03 m and adjust). Too short = black/missed patches (rays never reach the high); too long = cross-capture and skew. There is no universal number — there is a test bake and an inspection pass at 200% zoom on the seams and the tightest curvature.

Rule of inspection: bake errors concentrate at UV seams, at hard edges, at tight concavities (mouth interior, eye sockets, scale overlaps), and wherever high-to-low distance varies fastest. Inspect exactly those places, in Godot (not only in Blender), with a rotating environment light.

### Tangent space: MikkTSpace, and what it demands

Blender, Godot, and glTF all use **MikkTSpace** (Morten Mikkelsen's tangent-space standard) to compute per-vertex tangents from normals + UVs. Godot generates tangents with MikkTSpace on import when the mesh lacks them (the **Ensure Tangents** import option), and Blender computes MikkTSpace tangents for baking/rendering. This shared standard is why the Blender→Godot normal pipeline *can* be seamless — "synced" baking, where baker and renderer use the same tangent basis, is the modern expectation rather than the exception ([Godot proposals discussion on synced normal baking](https://github.com/godotengine/godot-proposals/issues/9446); [topology/UV guidance — MikkTSpace across Blender/engines/glTF](https://github.com/arg-software-factory/artyx-marketplace/blob/HEAD/plugins/game-ready-assets/skills/topology-and-uvs/SKILL.md)). What MikkTSpace demands of you:

- **One tangent source of truth.** Either export tangents from Blender and tell Godot not to regenerate, or omit tangents and let Godot generate them — but bake the normal map against the same basis that will render it. Baking against Blender's tangents and then letting a different-basis recomputation happen downstream is the classic seam generator.
- **UVs must be sane for tangents:** no degenerate (zero-area) UV triangles, no massively stretched islands in detailed regions, consistent winding. MikkTSpace inherits UV quality; a stretched island gives a skewed tangent frame and a normal map that shears under light.
- **Triangulation consistency** (again): MikkTSpace's interpolated tangent depends on which diagonal splits a quad. Bake and export the same triangulation.
- **OpenGL vs DirectX orientation is orthogonal to tangent basis:** Godot and glTF want OpenGL-style maps (green channel = +Y "up" in tangent space). A DirectX-style (Y−) map in this chain lights inverted. Fix by authoring OpenGL-style, or Godot Import → Normal Map Invert Y on the texture (see §2).

### Common bake artifacts and fixes

| Artifact | Cause | Fix |
|---|---|---|
| Black patches / missing detail | Rays miss the high (distance too short, cage gap) | Raise max ray distance / fix cage coverage; check high/low overlap |
| Wavy/skewed normals on flat areas | Rays capture angled neighbors (distance too long, no cage) | Shorten distance; use a tight cage |
| Visible seam lines at UV borders | Hard edge without seam; tangent mismatch; insufficient padding | Seam every hard edge; keep MikkTSpace end-to-end; increase bake margin/padding |
| Gradient across a large flat face | Low-poly face normal interpolates across a high-poly angle change with no support | Add support bevel/geometry, or split the face with a hard edge + seam, or use custom normals |
| Stepping / banding on smooth curves | 8-bit normal precision + low bake resolution | Bake at 2× and downsample; consider 16-bit bake source kept for future rebakes (ship 8-bit unless banding persists) |
| Mirrored side shades inverted | Tangent sign (handedness) lost in chain | Verify exported tangents include sign; test mirrored segment in Godot before full commitment (§4) |
| Detail doubled / ghosted | Low moved after cage/UV finalized; maps baked against different low versions | Freeze the low at bake time; version high/low/UV together; rebake all maps from one state |

### Procedural height → normal as a cheaper alternative — and its limits

Instead of sculpting a high-poly, you can author a greyscale heightfield procedurally in Blender (noise/Voronoi scale patterns, Musgrave ridges), convert it to a normal map (Bump node at render time, or bake height → normal via a Normal-from-height pass / Sobel conversion in an image tool), and apply it to a smooth low-poly. For the snake's *repeating body scales*, this is genuinely competitive: scales are a tiling, procedural-friendly pattern, and a procedural source is resolution-independent, tweakable by parameters, and perfectly repeatable across segments — properties a hand sculpt does not have.

Its limits are structural, not just quality-related:

- **No silhouette, no occlusion truth.** Height→normal fakes shading only. It cannot produce the parallax of overlapping scale plates, correct AO in crevices (you approximate AO from the same heightfield — plausible, not true), or any undercut/overhang (a heightfield is single-valued: one height per UV point).
- **No anatomical specificity.** The head — jaw mechanics, eye orbits, nostril pits, mouth interior — is not a heightfield pattern. Procedural height works for the body's repeating texture; the head still wants a sculpted bake (or a hybrid: sculpt bake for form + procedural detail added in the normal/roughness at texture stage).
- **Seam and derivative artifacts:** naive height→normal conversion amplifies UV seams (the Sobel filter samples across island borders) and produces faceting if the height source is low-resolution. Bake the conversion with padding awareness and at final-or-higher resolution.

**Project call:** hybrid. Procedural height→normal (+ matching roughness/albedo variation from the same procedural graph) for the body segment's scale micro-detail; a true high→low sculpt bake for the head and tail tip; combine in the final texture set. This keeps Exercise 1 achievable by script (procedural graph is code) without capping the hero's close-up quality.

## LODs & performance

Performance work on assets is mostly decided before Godot ever sees the file: LOD0 triangle count, material count, texture memory, and instance/draw structure. Godot gives you strong automatic tools for the distance problem — provided LOD0 is honest.

### Godot's automatic mesh LOD

By default, imported 3D *scenes* (glTF, `.blend`, Collada, FBX) generate mesh LODs automatically on import. The decimation uses the meshoptimizer library; at runtime Godot selects the LOD by **screen-space size** (how many pixels the mesh occupies), which automatically accounts for camera FOV and viewport resolution. It works on `MeshInstance3D`, `MultiMeshInstance3D`, `GPUParticles3D`, and `CPUParticles3D` ([Godot mesh LOD guidance for 4.7](https://github.com/xlanstar/godot-skills/blob/HEAD/skills/godot-mesh-lod-3d/SKILL.md); [StraySpark — LODs in Godot 4](https://www.strayspark.studio/blog/meshy-tripo-to-godot-4-gltf-lod-normal-maps)).

Key operational facts:

- **OBJ is the exception:** OBJ imported as a bare Mesh resource gets no scene LOD pipeline; only OBJ imported *as a Scene* does. Another reason OBJ is not in this pipeline.
- **Tuning knobs:** Project-wide `rendering/mesh_lod/lod_change/threshold_pixels` (default 1.0 — tuned to be near perceptually lossless; raise it to trade quality for performance). Per-viewport at runtime: `get_tree().root.mesh_lod_threshold`. Per-object: `lod_bias` on any `GeometryInstance3D` (> 1.0 = switch later / higher quality; < 1.0 = switch sooner). `ReflectionProbe` has its own threshold — raise it for always-updating probes.
- **Auto-LOD only helps at a distance.** LOD0 — the mesh you imported — is what renders up close, and LOD generation time grows with LOD0 complexity. A 1.9M-triangle AI raw output (§9) does not become a game asset because Godot will decimate its distant copies; its close-up cost, import time, memory, and collision cost are all still 1.9M-triangle problems. Budget LOD0 in Blender first, then let Godot handle distance.
- **Auto-LOD can break some meshes:** the import documentation and community guidance agree decimation "may occasionally introduce rendering issues (especially in skinned meshes)." If a skinned character's LODs tear or weights collapse, disable **Generate LODs** for that mesh in Advanced Import Settings and solve distance cost another way (fewer segments visible, visibility ranges, or hand LODs below). Test LOD transitions on the snake specifically: a tube whose segment silhouette pops between LODs will be noticed, because the character is the center of the screen.

### When to hand-author LODs

Hand-authored LODs are delivered not as meshes inside the `.glb` but via Godot **visibility ranges (HLOD)**: separate `MeshInstance3D` nodes (or a whole group of nodes swapped for one merged node) each with a `visibility_range_begin/end` (with fade margins) on `GeometryInstance3D`. Reach for hand LODs when:

- The asset is a hero with a silhouette that must degrade gracefully (the snake head: hand LODs preserve eye/jaw silhouette that decimation mangles).
- The swap is structural, not just decimation: high = individual segments + details; low = one merged tube; billboard/impostor at extreme range.
- Auto-LOD artifacts are verified on the asset and cannot be tuned away.
- The asset is skinned and auto-LOD is disabled for it (above).

Hand LOD rules: each step roughly halves triangles (LOD0 100% → LOD1 ~50% → LOD2 ~25% → LOD3 ~10% or impostor); preserve the silhouette and the material/texture set across steps so the swap reads as softening, not as a different object; keep the same pivot/origin at every level; set visibility ranges by *screen-relevant distance* in playtests, not by round numbers. For most props and environment pieces in this project, auto-LOD suffices and hand LODs are wasted effort — spend the hand-LOD budget only on the hero and on any asset that fails an auto-LOD visual test.

Separately, use **visibility ranges / HLOD** (not mesh LOD) when the levels are artist-authored groups — e.g., a detailed arena corner (dozens of nodes) swapping to a single merged proxy — because mesh LOD decimates individual meshes and cannot merge nodes.

### Triangle budgets (performance view)

Section 3 gave per-asset authoring budgets; the performance view is per-frame accounting:

- Track **visible triangles/frame** in Godot's Debugger → Monitors / profiler on the worst-case gameplay camera, on target hardware, at target resolution. Budgets that are not measured in the running game are fiction.
- Texture memory frequently binds before triangles on integrated GPUs and web: a scene of modest triangle count with twenty 4K texture sets will hitch on streaming/compression long before vertex cost matters. Enforce the §5 texture budget with the triangle budget.
- Shadows double-pay geometry: every shadow-casting mesh renders again into shadow maps. Set `cast_shadow` deliberately — the snake casts; tiny interior props may not need to; background clutter often should not.

### Draw call considerations for a segmented character

Each (mesh surface × material) combination on a visible `MeshInstance3D` is at least one draw call, plus shadow-pass draws. Structure the snake to keep its total trivially small:

- **One material per texture set** (§4): head (1), body segment (1), tail (1) = ~3 draw calls for the character if segments share the body mesh+material — regardless of whether the body is 8 segments or 30 — *if* the implementation batches or instances them.
- **Repeated segments:** if body segments are separate `MeshInstance3D` nodes sharing one mesh and material, Godot still issues per-instance draws (forward renderer) — 30 segments ≈ 30 draws, which is fine. If segment counts grow (long snake modes, multiple snakes), move to `MultiMeshInstance3D` for the body segments: one draw per MultiMesh (per surface) for all instances, with per-instance transforms updated from gameplay state. MultiMesh instances are not individually frustum-culled (the whole set is culled as one), which is acceptable for a character that is essentially always on screen.
- **Do not split materials per segment** for tint variation; use per-instance color / instance uniform parameters or vertex-color variation on a shared material instead. A new material per segment multiplies draws, shader permutations, and state changes for zero visual gain.
- Batching in Godot Forward+ is not Unity-style automatic static batching for arbitrary nodes; your batching tool is shared meshes/materials, MultiMesh for repeats, and merged geometry for static environment. Design assets accordingly: share first, merge static scenery where profiling says it matters.

## Rigging & animation readiness for a segmented snake

The snake is the character, the player avatar, and — in a grid-based Snake game — a data structure. Its visual representation must serve the grid logic exactly: the body is a sequence of discrete cells, turns are 90° events at cell boundaries, growth adds a segment, and death/collision are cell tests. The rigging choice is therefore a gameplay-architecture choice first and an art choice second.

### Option A — Bone chain with a single skinned mesh

One continuous tube mesh (head through tail) skinned to a chain of bones (one bone per segment position, plus head/jaw bones). The mesh deforms smoothly as bones follow the grid path with smoothing/interpolation between cell steps.

- **Pros:** smoothest possible motion — the body curves organically through turns instead of snapping; one draw-friendly mesh, one skin, continuous UVs/pattern flow head-to-tail with no per-segment seams; squash/stretch, breathing idle, and strike animations are natural in the animation system; head animation (jaw, tongue) integrates in the same skeleton/`AnimationPlayer`.
- **Cons:** fights the grid. Discrete logic must be continuously rendered: bone positions are derived by sampling the path history, and tight 180°-adjacent turns, growth pops, and tail-chasing configurations all need careful weight/length handling or the tube kinks, self-intersects, or changes length visibly. Weight painting a tube that bends 90° at *any* segment boundary (not just at authored joints) means *every* cross-section is a joint — weights must be uniform and rigorous along the whole body. Auto-LOD on skinned meshes is the known-fragile case (§7). Debugging "why does the body clip the wall visually while the grid says it fits" becomes a permanent tax, because the visual body and the logical body are different shapes.
- **Best if:** the design pivots to free (non-grid) movement, or to grid logic with heavily smoothed, continuous presentation and a team willing to own the path-sampling system.

### Option B — Per-segment rigid meshes on the grid/path

Head mesh, one body-segment mesh (instanced per body cell), and a tail mesh, each a rigid `MeshInstance3D`/`MultiMesh` instance placed and oriented per frame from the grid state. Corner/turn segments may be dedicated mesh variants (straight, left-turn, right-turn) or a single segment design that reads correctly under 90° rotation. Motion between cells is interpolated by translating/rotating instances along the cell transition; turns can use the corner variants or a brief rotation animation.

- **Pros:** visual == logical. Every segment occupies exactly its cell; collisions, growth (add an instance), and death (remove/flash instances) are trivially faithful. No skinning, no weights, no skinned-LOD problem; auto-LOD and MultiMesh batching work normally. Art is modular: segment variants (damaged, glowing, armored) are mesh/material swaps per instance. Determinism — the same grid state always renders identically — aids testing, replays, and screenshots for verification. This is how most polished grid-Snake presentations are actually built.
- **Cons:** motion is inherently more mechanical. Without care, movement reads as blocks sliding; the presentation layer must earn smoothness back via interpolation timing, corner pieces, scale "peristalsis" pulses traveling down the body, head leading with anticipation, and segment overlap (below) hiding the joints. Sharp 90° joins need either corner-variant meshes or enough overlap/bevel design that a straight segment rotated at a joint does not open a visible gap on the outside of the turn or intersect on the inside.
- **Best if:** the game stays grid-true — which is the stated design.

### Option C — Bend via shader

Segments (or a continuous tube) are rendered straight and bent in the vertex shader (e.g., curvature driven by a uniform/path texture; or per-instance shader parameters rotating segment instances along an arc). Variants range from a world-bend aesthetic effect to a full GPU path-follow.

- **Pros:** can give Option B's data model a surprisingly organic curve, or Option A's smoothness with the bend math in one auditable place; per-instance shader parameters on a shared material keep draw calls low.
- **Cons:** the bent result exists only in the vertex shader — CPU-side queries (picking, collision debug views, shadow correctness at extremes, LOD silhouette) see the unbent mesh; normals must be bent analytically or lighting flattens; every material variant must re-implement the bend; debugging requires shader tooling, not the animation editor. It is an optimization/embellishment layer, not a foundation for a first production character.

### Recommendation for this project

**Option B as the foundation, with presentation smoothing; keep Option A possible.** Concretely: discrete rigid segments driven by grid state, interpolated presentation movement, corner handling by segment design + overlap (below), and organic life added through head animation (the head *is* a small rigged/skinned or bone-animated piece — jaw and tongue want bones even in Option B), per-segment scale pulses via instance parameters, and material animation. This matches the game's discrete truth, keeps performance and LOD simple, and concentrates the "AAA feel" effort where the camera actually looks: the head and the first few segments.

### What to model NOW (Exercise 1) so animation later is not blocked

These decisions are cheap in Exercise 1 and expensive or impossible to retrofit:

1. **Segment pivot at the segment's logical center, at grid height.** Each segment mesh's origin sits at the center of its grid cell footprint, with the mesh centered on the origin in X/Z (Godot) and resting correctly in Y (origin at cell floor or cell center — pick one, document it, use it for head/body/tail identically). Gameplay will place instances by cell → world transform with zero per-asset offset hacks only if this holds. In Blender terms: model the segment centered on the world origin, length along the body axis (Blender Y, becoming Godot Z), and export with that origin intact.
2. **A consistent forward axis and taper direction.** Head front = `-Y` in Blender (`+Z` in Godot). Body segment "toward head" end and "toward tail" end must be distinguishable in the geometry (taper, scale pattern phase, scute direction) and consistent across every segment: the body tapers from thickest just behind the head to thinnest at the tail. If segments are one repeating mesh, encode taper *procedurally at placement time* by scaling instances along the chain (a per-instance scale curve from gameplay/render code) — which only works if the segment mesh is modeled at a neutral (unit) taper with its pattern designed to survive non-uniform instance scaling. Alternatively model 2–3 segment weight classes (front/mid/rear). Decide in Exercise 1; a segment modeled with baked-in random taper direction blocks both approaches.
3. **Overlap geometry at both ends.** Model each segment slightly *longer* than its cell pitch (e.g., 8–15% overlap budget, tuned in the turn test), with end cross-sections slightly *undersized* (a gentle inset/necking) so that when two segments meet at a 90° turn, the outer side does not gap and the inner side does not visibly intersect. Scale plates that overlap like shingles (head-end overlapping tail-end, matching the pattern direction in (2)) turn the joint problem into a design feature. Verify with a physical test: assemble head + 4 segments + tail in Blender in a straight line and in a tight U-turn at final cell pitch and inspect both configurations before calling the segment done.
4. **Head as its own asset with an animation-ready structure.** Model the head separately from segment 1, with: jaw as a separable piece (or skinned region) whose pivot sits at the jaw hinge point (origin placement again — a jaw mesh whose origin is at the hinge rotates correctly with a single bone or even a plain node rotation; a jaw modeled fused into the skull with a center origin must be re-cut later); eye geometry as distinct spheres/seats (for glint materials and potential eye-look animation); tongue as its own thin mesh with its origin at the mouth interior (flick animation = scale/translate along its axis); and a neck blend piece (a short, wider flare) that overlaps segment 1 generously to hide the head/body joint at all head pitch/yaw angles.
5. **Weight-ready topology even for the rigid route.** Keep circumferential loops at segment ends (§3) and clean tube topology on the head/neck. If the project later adopts Option A (skinned tube) for a cinematic or a free-move mode, a head + first-segments skinned variant can be built from these meshes without remodeling. Conversely, do not spend Exercise 1 time painting full-body weights — that is Option A work the chosen design does not need.
6. **UV and material seams at segment boundaries.** End each segment's UV/material assignment at its physical ends (§4, §5), so segments can be tinted, damaged, or swapped per-instance without a pattern continuing across a joint it cannot actually continue across — except the dorsal pattern's *phase*, which should be designed so segment N's tail-end pattern visually continues segment N+1's head-end pattern when both are at neutral scale. Test by tiling two segment instances in a row and looking for a pattern jump.
7. **Tail as a tapered end-cap asset,** modeled with the same pivot/axis rules, ending in a rounded/pointed tip with several dedicated loops so a tail-wag or rattle-style animation (node rotation on the tail instance, or a tiny 3-bone chain if later skinned) reads well.
8. **Scale reference and naming in the file:** include (on a non-exported layer/collection) a 1 m reference cube and the grid-cell footprint square at the segment base, and name objects exactly per §2 (`Head`, `Jaw`, `Tongue`, `Segment`, `Tail`, plus `Armature` if the head rig is started). The next worker — human or agent — should be able to open the `.blend`, run the export preset, and get §10's Godot result without tribal knowledge.

## AI 3D generation tools — 2026 survey

The 2026 landscape is no longer "one model that makes blobby meshes." There are more than a dozen production-grade generators, split between closed hosted services and open-weight models you run yourself, plus aggregators that put several engines behind one UI/API. No single model wins on every axis — speed, geometry detail, texture quality, topology control, and openness each have a different leader — which is itself the most important market fact ([3D AI Studio — State of AI 3D Generation 2026](https://www.3daistudio.com/state-of-ai-3d-generation-2026); [eWeek — Best AI 3D Generators for 2026](https://www.eweek.com/artificial-intelligence/best-ai-3d-generators/)). Pricing below is as reported by those surveys and vendor-tier summaries in September–October 2026; credit systems change frequently, so treat prices as indicative and re-verify before any purchase (flagged in §11).

A shared baseline first, because it applies to every tool: **raw generation output is not a game asset.** Independent hands-on tests in 2026 repeatedly find the same profile — impressive silhouette and texture at first glance, then, on inspection: very high triangle counts, dense even triangulation with no edge flow, non-watertight shells and floating fragments on some outputs, UVs laid out for the dense mesh (so any decimation forces a rebake), scale normalized to roughly a unit cube (real-world size unknown), and origin wherever the generator left it. The prep chain in Blender (§2, failure table; §3 retopo; §4 UV; §6 bake) is still required; generation changes where the chain *starts*, not whether it runs ([StraySpark — what Meshy and Tripo hand you](https://www.strayspark.studio/blog/meshy-tripo-to-godot-4-gltf-lod-normal-maps)).

### Meshy (Meshy 5 / 6, with 7.x rolling out)

- **Inputs/outputs:** Text, single image, and multi-view generation; texturing as a separate pass; remesh/topology tools; auto-rigging and an animation library; Blender/Unity/Unreal plugins and an API. Exports GLB, FBX, OBJ, USDZ, STL, BLEND, and others.
- **Mesh/UV/PBR specifics (verified from API documentation summaries, Sept 2026):** remesh is **off by default** on recent models — you receive the raw generation mesh unless you request remeshing. Remesh defaults: triangle topology, 30,000-face target (range ~100–300,000); a separate "Smart Topology" mode targets ~4,000 faces (capped ~15,000) with cleaner game intent. PBR is **off by default** (`enable_pbr`): a default download is base-color only, with flat roughness/metallic in Godot until you enable PBR or author maps yourself. Texture resolution defaults to 2K, with 4K/8K on request. One independent test measured a Meshy 6 image-to-3D result at ~206k faces / ~103k vertices, watertight, in about a minute.
- **Pricing/access:** Free tier (~100 credits/month, no card; a textured model costs roughly 30 credits — generation ~20 + texturing ~10 — so ~3 finished models/month free); Pro from **$20/month**, Studio ~$60/month. Per-model API cost roughly $0.10–$0.30 in aggregator comparisons.
- **Licensing:** Free-tier output is **CC BY 4.0** — commercial use allowed *with attribution*. Paid plans remove the attribution requirement under a private license.
- **Fit:** the most established end-to-end pipeline (generate → texture → rig → animate) and the safest hosted default for one-off props. Its defaults are also the trap: ship a default download unexamined and you ship a 200k-triangle, base-color-only prop.

### Tripo (Tripo 3.0, VAST AI)

- **Inputs/outputs:** Text, image, multi-view; high-detail, quad, and low-poly topology options; "Smart Low Poly" reduction; native PBR texture sets up to 4K; rigging/animation workflow; API. Exports GLB, FBX, OBJ, STL.
- **Mesh specifics:** the speed champion in 2026 surveys — usable drafts in under ~30–60 seconds. At best quality it is also the density extreme: one September 2026 free-tier test produced **1,911,270 faces / 1,012,219 vertices**, non-watertight (open shells in thin/furry regions), requiring Tripo's own retopo pass (targetable 500–50,000 polys, tris or quads, extra credits) to become usable — after which reviewers noted the detail advantage largely evaporated and fingers became "mitten-ish" at 10k via Smart Low Poly. In controlled one-prompt comparisons, Tripo often wins draft-to-decision speed and fine detail, sometimes at the cost of proportion/perspective accuracy from a single view.
- **Pricing/access:** Free tier (~200 credits/month; best-quality image-to-3D ~55 credits, free generations may run an older model version); Pro from **$19.90/month**. Exports are gated behind paid tiers in some flows.
- **Licensing:** free output has historically been CC BY / non-commercial depending on tier and flow, with clean commercial rights on paid plans — verify the exact terms on the flow you use before shipping (see §11).
- **Fit:** fastest iteration loop for exploring many prop concepts; budget the retopo/rebake step into every Tripo hero use.

### Hyper3D Rodin (Rodin Gen-2 / Gen-2.5, Deemos)

- **Inputs/outputs:** Text or up to five reference images, with extensive mesh and material controls; high-detail geometry emphasis; exports OBJ, FBX, GLB, USDZ, STL.
- **Mesh specifics:** consistently rated the maximum-geometry-detail option — in comparative tests, the cleanest hard-surface detail ( crisp manufactured edges, hardware, locks) — at the cost of the highest triangle counts (~613k faces in one high-quality test) and slower generation. Positioned for film-grade hero assets rather than out-of-the-box game props.
- **Pricing/access:** Free tier to start; Creator from **$30/month**; full "any-use" licensing is reported at a higher tier (~$120/month) — the free/lower tiers carry limited use rights. Per-model API cost ~$0.50+, the premium end of the survey range.
- **Fit:** when one hero prop justifies manual retopo anyway (a centerpiece weapon, the arena's focal statue), Rodin's geometry head start is real. For volume props, its cost in money and cleanup exceeds its benefit.

### Hunyuan3D (Tencent, 2.1 with 3.x line emerging)

- **Inputs/outputs:** Open-weight image/text-to-3D in two stages — shape generation, then a dedicated paint/texture stage producing true PBR maps (albedo, metallic, roughness). Also available hosted via aggregators/APIs. Shape stage needs ~10 GB VRAM; the **full shape+texture pipeline needs ~29 GB VRAM** by the repository's own figures — beyond most consumer cards for local full-pipeline runs, though shape-only and distilled Turbo/Fast/mini variants run in 5–6 GB.
- **Quality:** repeatedly rated best-in-class textures/PBR among open models, with strong geometry; the two-stage design is slower than single-pass feed-forward models, and no official per-asset timing is published for 2.1.
- **Pricing/access:** No model fee — you pay in hardware or cloud GPU. Hosted access via aggregators is per-generation cents-scale.
- **Licensing — read this before shipping:** **Tencent Hunyuan 3D 2.1 Community License**, not a standard open-source license. Commercial use is permitted *with conditions*: a 1M monthly-active-user cap above which a separate Tencent license is required; the license **does not apply in the EU, UK, and South Korea**; and outputs may not be used to improve non-Hunyuan AI models ([TripoSR.org — Hunyuan3D vs TRELLIS.2 licensing comparison](https://triposr.org/blog/hunyuan3d-vs-trellis)). For a US-based indie project under the MAU cap this is likely workable, but it is a legal review item, not a footnote (§11).

### TRELLIS.2 (Microsoft) and the open feed-forward models

- **TRELLIS.2 (4B):** Open under **MIT** (with a nuance: its rendering dependencies `nvdiffrast`/`nvdiffrec` carry separate NVIDIA terms, and its DINOv3 image encoder carries its own license, so some pipelines classify output as commercial-conditional — check the exact stack you run). Produces high-resolution (up to 1536³) assets with PBR in ~3 s (512³) to ~60 s (1536³) on an H100; ~24 GB VRAM class locally. Rated the open-source standout for combined topology + PBR quality in 2026 comparisons.
- **TripoSR / Stable Fast 3D (SF3D):** MIT-licensed feed-forward models: sub-second to <0.5 s (A100) drafts on 6–8 GB VRAM. Lowest fidelity of the group — melted details on hard prompts are documented — but unmatched for volume blockouts and placeholder generation at zero marginal cost.
- **Others to know:** ByteDance **Seed3D 2.0** (closed API; reported 69–89.9% blind human-preference win rates vs commercial rivals in April 2026 vendor/community reporting — treat as a vendor-adjacent claim until independently replicated); **Sloyd** (template-based, controllable game-ready assets, Plus from $15/month — interesting because its parametric/template model gives more dimensional control than pure generation); **Step1X-3D** (Apache-2.0, ~10 GB VRAM); **Hi3DGen** (MIT, geometric precision focus). Aggregators — **3D AI Studio, fal.ai, Replicate** — expose several of these engines behind one interface at roughly $0.02–$0.50 per generation, enabling "run the same input through three engines, keep the best" workflows.

### Comparison snapshot

| Tool | Access | Headline strength | Raw density (typical test) | PBR by default? | License headline |
|---|---|---|---|---|---|
| Meshy 6/7 | Hosted, free tier + $20/mo Pro | End-to-end pipeline, texture quality, rigging | ~200k faces | **No** — enable PBR; remesh off by default | Free = CC BY 4.0; paid = private |
| Tripo 3.0 | Hosted, free tier + $19.90/mo Pro | Speed, detail at best quality | Up to ~1.9M faces | Yes (sets to 4K) | Free restricted; paid = commercial — verify flow |
| Rodin Gen-2 | Hosted, Creator $30/mo | Max geometry detail, hard-surface | ~600k faces | Yes, with controls | Tiered; full use at high tier |
| Hunyuan3D 2.1 | Open weights, self-host | Texture/PBR quality | Varies; full pipe ~29 GB VRAM | Yes (dedicated paint stage) | Community license: MAU cap, EU/UK/KR excluded |
| TRELLIS.2 | Open, MIT* | Open quality/speed balance | Res-dependent (512³–1536³) | Yes | MIT* (dependency/encoder caveats) |
| TripoSR / SF3D | Open, MIT | Sub-second drafts, 6 GB VRAM | Low–mid | Basic | MIT, unrestricted |

### Honest verdict — grounded in the snake

**Where AI generation beats scripting / hand-authoring:**

- **Speed of the first draft.** Thirty seconds to a textured, recognizable object is a real capability discontinuity. For *exploration* — "show me five directions for the arena's frog statue / the pickup orb / a gnarled tree" — generation collapses a half-day of blockout work into a coffee break, and the drafts are good enough to art-direct from.
- **Organic one-offs.** A unique rock formation, a fossil skull set-dressing piece, a one-time boss-arena centerpiece: forms with no repetition, no deformation rig, and no dimensional contract are generation's home turf. Sculpt-like irregularity is what these models are best at, and a single retopo+bake pass (§3, §6) converts the best of them into shippable props.
- **Texture starting points.** Hunyuan3D/Meshy-class PBR texturing on a *retopologized* mesh (re-texture/re-paint flows) can produce a credible base that a human or procedural pass then art-directs, faster than painting from a blank UV.
- **Placeholder volume.** MIT-licensed local models (TripoSR/SF3D) generate unlimited greybox-plus placeholders at zero marginal cost, keeping level design unblocked while hero assets are authored properly.

**Where it loses — decisively, for this project's hero:**

- **Topology control.** The snake must bend (or join) at *every* segment boundary, hold volume, and keep a pattern phase across segments. Generated meshes have no edge flow, no loops at joints, no concept of a joint. Retopologizing a generated snake is not a cleanup step; it is remodeling the snake, with the generated mesh as a reference sculpt. At that point the generator saved you the sculpt — the one stage a procedural Blender script also produces, with parameters.
- **Segment and pivot discipline.** The design (§8) needs N identical-pitch segments, origins at cell centers, consistent taper direction, and engineered overlap. A generator produces *a* snake: one continuous, unit-cube-normalized, arbitrarily-origined object whose "segments" are surface decoration. Slicing it into grid-true segments with correct pivots is manual reconstruction. A Blender Python script that builds a segment from a profile curve gets pitch, pivot, taper, and overlap **exactly**, every run, for free.
- **Texel discipline.** Generated textures are baked to the generated dense mesh's auto-UVs. Any topology fix invalidates them, forcing a rebake that loses the generator's texture advantage; and auto-UVs do not target 1024 px/m, do not put the head on its own set, and do not design a repeating body set. You pay the UV/bake work either way (§4, §6).
- **Repeatability and versioning.** A scripted model is diffable code: change `segment_radius` from 0.42 to 0.45, re-run, get the same snake, thicker — in version control, reviewable, reproducible on CI. A generated model is an artifact of a prompt, a seed (when exposed), a model version the vendor may silently update, and a credit balance. "Make it 7% thicker, keep everything else" is a one-line change in a script and a re-roll of the dice in a generator. For a hero character that will iterate for the life of the project, that asymmetry is decisive.
- **Licensing surface.** Scripted/hand-authored assets have no third-party license. Generated assets import CC BY attribution duties (Meshy free), regional exclusions and MAU caps (Hunyuan3D), tier-dependent commercial rights (Tripo, Rodin), or encoder/dependency caveats (TRELLIS.2 stacks) — each manageable, none free of review cost, and all unnecessary for the hero.

**Bottom line for the snake:** generate the *set dressing*; script the *snake*. Use AI generation for one-off organic props, arena dressing, concept drafts, and placeholders — with the §10 prep loop applied without exception. Build the hero (head, segment, tail) by parametric/scripted modeling in Blender, where pitch, pivot, taper, overlap, UV design, and texel density are exact and versioned. Revisit this verdict if a future tool exposes true parametric segment control with clean quad output — none surveyed in October 2026 does.

## Recommended pipeline for this project

The concrete make → export → import → verify loop for Exercise 1. Written to be followed verbatim by another worker (human or agent). Assumes: Blender 4.x (current stable), Godot 4.7 (pinned build), project texture sets and budgets as defined in §3–§5.

### A. Make (Blender, scripted where possible)

1. Open the Exercise 1 Blender file (or run the build script headless: `blender --background --python build_snake.py`). Confirm scene units: Metric, Unit Scale **1.0**; frame rate irrelevant for statics.
2. Build/verify the three assets on the export collection, modeled facing **−Y**, resting at the documented pivots (§8): `Head` (with `Jaw`, `Tongue`, neck flare as named sub-objects/parts), `Segment` (neutral taper, overlap geometry both ends, circumferential end loops), `Tail`.
3. Check dimensions in the N-panel against the design (segment length = grid pitch × (1 + overlap allowance); head length/width per design sheet). Check the turn test: duplicate the segment chain in a U-turn on a scratch layer; confirm no outer gap / inner intersection; delete the test copies.
4. Apply transforms on export objects: select all → `Ctrl+A → All Transforms`. Confirm scale reads 1,1,1 and rotations 0.
5. Mesh hygiene pass per asset: Merge by Distance (tolerance per script default), Delete Loose, Recalculate Outside normals; run mesh analysis — zero non-manifold edges, zero zero-area faces. Triangulate via modifier (keep the modifier; export will apply it).
6. UVs per §4: body seam on the belly centerline; head seams hidden; texel density set to **1024 px/m** (Texel Density Checker — set, apply, verify readout), head islands scaled to their own-set target; pack with ≥16 px margin at 2048². Confirm no island outside 0–1.
7. Materials per §5: one Principled material per texture set (Head / Body / Tail). Procedural pattern graph drives albedo/roughness variation; bake the texture set (albedo sRGB; normal, ORM **Non-Color**) at final resolutions (Head 2048², Body 2048², Tail 1024²) with bake margin 16 px. Head normal from the high-poly sculpt bake (§6, cage fitted, test-bake inspected at seams/jaw/eyes); body normal from procedural height→normal (hybrid rule, §6). Pack ORM (R=AO from bake, G=roughness, B=metallic=black). Reconnect the *baked* maps into the Principled material and confirm the material preview matches the bake.
8. Enable **Backface Culling** on each material (Material Properties) unless a part is intentionally double-sided (tongue: double-sided deliberately, noted).
9. Save the `.blend` (source of truth, versioned). Do not destructively apply the Armature modifier (if a head rig exists) or Subsurf on the working meshes — export applies what it needs.

### B. Export (Blender → glTF)

10. Select exactly the export collection's objects (plus the head armature if present). `File → Export → glTF 2.0`, Format **glTF Binary (.glb)**, one file per asset: `snake_head.glb`, `snake_segment.glb`, `snake_tail.glb` into the staging folder.
11. Export preset (every time, no improvisation): Include → Selected Objects **on**; Transform → +Y Up **on**; Geometry → Apply Modifiers **on**, UVs **on**, Normals **on**, Tangents **on** (normal-mapped assets), Vertex Colors off (unless designed), Materials **Export**, Images Automatic; Animation → on only for the head (NLA strips as source, clip names verified: `idle_sway`, plus jaw/tongue tests if present), Sampling on if constraints were baked; Skinning on only for the head; Shape Keys per design; **no LOD meshes in the file**.
12. Validate each `.glb` before Godot: open in a glTF viewer (Blender re-import into a scratch file, or a standalone validator/viewer); check triangle count (Head ≤10k target, Segment ≤1.5k, Tail ≤3k — record actuals), dimensions in meters, forward = +Z in the viewer, materials present with all maps.

### C. Import (Godot 4.7)

13. Copy the `.glb` files into the project (e.g., `res://assets/snake/`). **Focus the Godot editor and let the import pass complete** — watch the import progress finish with no errors. (Automation/CI equivalent: `godot --headless --editor --path <project> --import --quit`, then check the log — skipping this step is the fallback-material bug in §2.)
14. Select each `.glb` in the FileSystem dock → Import dock: Root Type `Node3D`; Root Scale 1.0; Meshes → Ensure Tangents on (harmless if tangents exported), Generate LODs **on** for Segment/Tail, **on-but-inspect** for Head (disable for Head if LOD inspection in step 16 shows silhouette damage, and note the HLOD follow-up); Light Baking = Disabled (dynamic character); Animation import on for Head. Reimport if you changed anything.
15. (Production option, do once materials stabilize) Advanced Import Settings → Materials → Extract to `res://assets/snake/materials/` so material tweaks version independently of mesh re-exports.

### D. Verify (Godot — the asset is not done until all boxes pass)

16. Instance all three assets in the verification scene next to a **1 m reference cube** and a grid-pitch floor square: (a) scale correct (segment spans exactly its pitch + overlap), (b) facing correct (head front = +Z model front), (c) materials correct — dorsal/ventral albedo right, scales catch light (normal working: rotate a key light / use the environment preview and confirm bumps are bumps, not dents), roughness variation visible, no pink/grey fallback material, (d) triangle counts in the debugger match step 12 actuals at LOD0, (e) walk the camera away and confirm LOD transitions do not pop the silhouette objectionably, (f) assemble head + 6 segments + tail in a straight line and a U-turn from instances — pattern phase continuous, joints closed, (g) for the head, play each animation clip in the AnimationPlayer.
17. Record the verification (screenshot + the numbers from 12/16) in the Exercise 1 handoff note. Any failure routes back to the *earliest* responsible step (scale → step 4; material → step 7/14; silhouette → step 2/3) — fix the source, re-export, re-import, re-verify. Never patch the imported scene.

**Loop invariant:** `.blend` (and its build script) is the source of truth; `.glb` is a build artifact; the Godot import is a build step; the verification scene is the test. Treat any hand-edit downstream of the `.blend` as a bug in the pipeline, not a fix.

## Open questions

Items that could not be fully verified tonight, or that require a decision/test on the pinned builds. None of these block Exercise 1 if the conservative defaults in §10 are followed.

1. **Godot 4.7 exact extension support matrix.** Which `KHR_materials_*` extensions (clearcoat, transmission, sheen, specular/ior, emissive_strength) the pinned 4.7 build's glTF importer honors, drops, or approximates was not verified against the 4.7 source/release notes tonight. Required test: one-material-per-extension export → import → inspector comparison on the pinned build, recorded in the project. Until then, stay in the glTF core material model (§5).
2. **Blender version ↔ exporter behavior for Apply Modifiers + Armature.** The interaction is version-sensitive historically. The exact Blender build used for Exercise 1 should run the posed-export test (§2) once and record the result; this dossier's guidance assumes a current Blender where export-time Apply Modifiers preserves skinning, but it was not re-tested tonight.
3. **AI tool pricing/terms volatility.** Meshy/Tripo/Rodin credit costs, free-tier model versions, and per-flow license terms (especially Tripo's free-vs-paid rights per generation mode, and Rodin's full-use tier price) were taken from September–October 2026 surveys and secondary summaries, not from logged-in vendor checkout pages. Re-verify on the vendor sites before any spend or any commercial shipment decision involving generated assets.
4. **Hunyuan3D 3.x licensing.** Whether the emerging 3.x line keeps the 2.1 Community License terms (MAU cap, EU/UK/KR exclusion, no-training clause) or changes them was not verified tonight. Do not assume 2.1 terms carry over — in either direction.
5. **Seed3D 2.0 preference claims.** The 69–89.9% human-preference win rates are vendor/community-reported (April 2026) without an independent replication located tonight. Interesting, not load-bearing; no pipeline decision in this dossier depends on it.
6. **Auto-LOD quality on the actual snake segment.** Whether meshoptimizer decimation preserves the segment silhouette/pattern acceptably at gameplay distances is asset-specific and untested — it is step 16(e) of the pipeline by design. If it fails, the follow-up (hand HLOD set for the hero) is scoped in §7 but not yet budgeted.
7. **Draw-call / MultiMesh threshold in the real game.** The segment count at which MultiMesh instancing becomes necessary depends on final snake length modes, snake count, and scene load — to be set by profiling the first playable, not by this dossier.
8. **Texture compression specifics on target hardware.** Godot's VRAM-compressed import formats (BPTC/BC) behavior on the project's actual target GPUs — particularly normal-map quality at 1024² for the tail set — should be eyeballed on hardware during Exercise 1 verification; tonight's guidance uses documented defaults.
9. **Whether a `.blend`-direct import shortcut is wanted for iteration.** Rejected as the shipping route in §2, but the team may still want it as a local iteration convenience. That is a workflow decision for the project lead; it does not change any standard in this dossier.
