# Reference-match input package (2026-10-17)

Contents:

- `BRIEF.md` — the complete build instructions. Read it first.
- `REFERENCE.png` — the target image the model must match.
- `DOSSIER.md` — the project modeling dossier (method source: export
  contract, budgets, texturing, rigging).
- `REVIEW-STAGING.md` — the plain-background staging standard for the
  review captures.
- `assets/` — Exercise-2 base model: `snake_head.glb`,
  `snake_segment.glb`, `snake_full.glb`, and `assets/textures/`
  (albedo, normal, ORM, height, glow PNGs).
- `base/` — Exercise-2 build scripts (`build_snake.py`,
  `build_textures.py`) and the staging render script
  (`render_staging.py`).
- `game-demo/` — the Godot 4.7 game project the model ships in
  (import-extracted caches excluded; the editor import pass
  regenerates them).
- `MANIFEST.sha256` — SHA-256 of every file in this package except the
  manifest itself. Verify after unzipping:

      sha256sum -c MANIFEST.sha256

  (run from the folder this README sits in; every line must say OK).
