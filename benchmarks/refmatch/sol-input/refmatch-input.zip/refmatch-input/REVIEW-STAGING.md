# Review staging standard (owner's direction, 2026-10-17)

Christopher, reviewing the Exercise 1 in-game captures: **"Models should
be staged in a plain background for review."**

Rule for every model review capture in this workspace, from Exercise 2
onward:

- Stage the model on a **plain background** — a neutral, featureless
  backdrop (plain mid-gray or similar), neutral studio-style lighting,
  nothing else in frame: no game floor/grid, no environment, no second
  model, no HUD.
- Frame the whole subject (full snake for the wide shot; head assembly
  for the close-up), centered, at a distance where surface detail is
  actually judgeable.
- In-game captures (shipping camera, side-by-side with the game) remain
  useful as *context* evidence, but they are not the review deliverable.
  Review = plain background.
- Baseline and after shots for an exercise use the SAME staging (same
  backdrop, lighting, framing) so the comparison is honest.
