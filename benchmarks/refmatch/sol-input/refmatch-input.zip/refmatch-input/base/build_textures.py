#!/usr/bin/env python3
"""Procedural PBR texture set for the production snake.

Exercise 1 (MODELS) shipped a regular quilt of identical plates; the
blind judge called it a procedural tile, not manufactured armor, and
read the surface as plastic. Exercise 2 (MATERIALS) keeps the material
identity (dark blue-green gunmetal plating, near-black seams, mint
emission living in geometry) and rebuilds the surface read:

  * Irregular plate field (fix #2): per-plate size / offset / rotation /
    dome-height variance on a lattice whose steps divide the tile
    exactly (2048 = 11 ring steps = 10 row steps), per-ring phase
    offsets, occasional darker "replacement" plates and rare recessed
    gap plates showing substrate.
  * PBR breakup (fix #3): per-plate roughness and metallic offsets
    carried through a plate-ID map so all maps agree, low-frequency
    mottling, large soft grime blotches and polished patches, edge wear
    derived from the height gradient, scratches / gouges / smudges at
    meaningful amplitude, AO-style darkening in the seams.
  * Joint detail (fixes #4/#5): circumferential bands at the segment
    pinch U positions carry an AO valley, a panel seam groove,
    fastener dots, and vent slots. Band 2 lands on the head's brow/eye
    zone, so its groove is faded and its fasteners skipped near the
    eye latitudes (theta ~ +/-2.0 rad).

Outputs (2048x2048, tileable in both axes; one tile covers 1.55 x 1.55
world units at the UV scale build_snake.py assigns):
  snake_albedo.png  - sRGB plate color
  snake_height.png  - grayscale height (plate domes high, seams low)
  snake_orm.png     - R = AO, G = roughness, B = metallic (glTF packing)
  snake_glow.png    - 256x64 emission falloff gradient for the joint
                      rings (bright core, dark edges) - fix #4
Normal map is derived from the height map with the workspace tool:
  python3 ~/workspace/tools/height2normal.py snake_height.png snake_normal.png --strength 2.2

UV convention produced by build_snake.py: U runs along the body length,
V runs around the circumference (and wraps the tile twice). Segment
pinch zones sit at |x| in [0.42, 0.60] of the segment's +-0.60 length,
i.e. U in [0.271, 0.387] and [0.613, 0.729].
"""
import math
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W, H = 2048, 2048
SEAM = (8, 12, 14)
PAD = 20

# Periodic lattice: steps divide the tile exactly.
RINGS, ROWS = 11, 10
RING_STEP = W / RINGS      # 186.18 px along U
ROW_STEP = H / ROWS        # 204.8 px along V
PLATE_W, PLATE_H = 226, 216

# Joint bands (segment pinch zones, see module docstring).
BANDS = (0.329, 0.671)          # band centers in U
BAND_HALF = 62                  # px, cosine falloff half-width
GROOVE_U = (0.352, 0.648)       # panel seam line inside each band
VALLEY_U = (0.387, 0.613)       # pinch edge the AO ramps toward
EYE_Y = (745, 1304)             # texture rows of the eye latitudes

rng = random.Random(20261017)


def plate_params(k, m):
    """Deterministic per-plate variation, keyed by lattice index so
    wrapped copies of a plate share parameters exactly."""
    r = random.Random(77000 + k * 131 + m * 717)
    p = dict(
        sx=r.uniform(0.90, 1.11), sy=r.uniform(0.90, 1.11),
        jx=r.uniform(-9, 9), jy=r.uniform(-9, 9),
        rot=r.uniform(-1.8, 1.8),
        light=r.uniform(0.82, 1.16), hue=r.uniform(-0.05, 0.05),
        dome=r.uniform(0.72, 1.28),
        rough=r.uniform(-0.10, 0.12), metal=r.uniform(-0.05, 0.05),
        cluster=r.random() < 0.14,
        gap=r.random() < 0.025,
    )
    if r.random() < 0.06:  # replacement plate: darker, cooler, rougher
        p["light"] *= r.uniform(0.66, 0.80)
        p["hue"] -= 0.05
        p["rough"] += 0.10
    return p


def plate_color(p):
    r = int(max(0, min(255, (58 + p["hue"] * 120) * p["light"])))
    g = int(max(0, min(255, (84 + p["hue"] * 60) * p["light"])))
    b = int(max(0, min(255, (94 - p["hue"] * 80) * p["light"])))
    return (r, g, b)


def plate_patch(p):
    """Render one plate to small (color, height, mask) patches.

    The color art is drawn on an RGB layer and the alpha silhouette
    on its own L layer, then merged. (First Exercise 2 draft drew the
    decorative inset straight onto an RGBA patch: PIL ImageDraw
    replaces rather than composites, so the inset's alpha 64 became
    the plate's alpha across its whole interior and every paste
    blended at 25% strength — washed-out domes and hollow-looking
    plates. The silhouette must be independent of the art.)"""
    w = int(PLATE_W * p["sx"])
    h = int(PLATE_H * p["sy"])
    pw, ph = w + 2 * PAD, h + 2 * PAD
    rad = max(8, int(26 * min(p["sx"], p["sy"])))
    img = Image.new("RGB", (pw, ph), (0, 0, 0))
    d = ImageDraw.Draw(img)
    sil = Image.new("L", (pw, ph), 0)
    ImageDraw.Draw(sil).rounded_rectangle(
        [PAD, PAD, PAD + w, PAD + h], radius=rad, fill=255)
    him = Image.new("L", (pw, ph), 24)
    hd = ImageDraw.Draw(him)
    if p["gap"]:
        # Recessed substrate where a plate is missing.
        d.rounded_rectangle([PAD, PAD, PAD + w, PAD + h], radius=rad,
                            fill=(15, 21, 24))
        d.rounded_rectangle([PAD, PAD, PAD + w, PAD + h], radius=rad,
                            outline=(54, 68, 72), width=3)
        hd.rounded_rectangle([PAD + 4, PAD + 4, PAD + w - 4, PAD + h - 4],
                             radius=rad, fill=int(52 * p["dome"]))
    else:
        col = plate_color(p)
        d.rounded_rectangle([PAD, PAD, PAD + w, PAD + h], radius=rad,
                            fill=col)
        # Exercise 1 drew this inset at alpha 70 over the base on an
        # RGB canvas; pre-blend the same mix here.
        inset = tuple(int(c * 0.725 + min(255, c * 1.15) * 0.275)
                      for c in col)
        d.rounded_rectangle([PAD + 10, PAD + 10, PAD + w - 16, PAD + h - 30],
                            radius=max(6, rad - 6), fill=inset)
        lip = tuple(int(c * 0.255 + min(255, c * 1.5) * 0.745)
                    for c in col)
        d.line([PAD + 14, PAD + h - 8, PAD + w - 14, PAD + h - 8],
               fill=lip, width=5)
        # Dome steps: a high base (so plate bodies sit near Exercise
        # 1's ~170-200 working range) with the per-plate dome factor
        # scaling the whole profile, not multiplying it toward zero.
        for i, frac in enumerate((0.42, 0.66, 0.88)):
            g = int(min(244, 105 * p["dome"] + 120 * frac))
            hd.rounded_rectangle(
                [PAD + 5 + i * 8, PAD + 5 + i * 8,
                 PAD + w - 5 - i * 8, PAD + h - 5 - i * 8],
                radius=max(6, rad - 4), fill=g)
    img = img.rotate(p["rot"], resample=Image.BILINEAR)
    sil = sil.rotate(p["rot"], resample=Image.BILINEAR)
    him = him.rotate(p["rot"], resample=Image.BILINEAR)
    out = img.convert("RGBA")
    out.putalpha(sil)
    return out, him, sil


def draw_plates(albedo, height, id_img):
    """Stamp the irregular plate field; returns plate records and the
    per-plate roughness/metallic offset LUTs (index = plate id)."""
    params = {(k, m): plate_params(k, m)
              for k in range(RINGS) for m in range(ROWS)}
    rough_lut = np.zeros(RINGS * ROWS + 1, dtype=np.float32)
    metal_lut = np.zeros(RINGS * ROWS + 1, dtype=np.float32)
    rough_lut[0], metal_lut[0] = 0.10, 0.0   # exposed seam: rougher
    for (k, m), p in params.items():
        pid = k * ROWS + m + 1
        rough_lut[pid] = p["rough"]
        metal_lut[pid] = p["metal"]
    ring_off = {k: random.Random(555 + k).uniform(0, ROW_STEP)
                for k in range(RINGS)}
    ring_jx = {k: random.Random(919 + k).uniform(-3, 3)
               for k in range(RINGS)}
    records = []
    for k in range(-1, RINGS + 1):
        kk = k % RINGS
        for m in range(-1, ROWS + 1):
            mm = m % ROWS
            p = params[(kk, mm)]
            pid = kk * ROWS + mm + 1
            cx = k * RING_STEP + ring_jx[kk] + p["jx"]
            cy = ring_off[kk] + m * ROW_STEP + p["jy"]
            img, him, mask = plate_patch(p)
            px, py = int(round(cx - img.width / 2)), int(round(cy - img.height / 2))
            albedo.paste(img, (px, py), mask)
            height.paste(him, (px, py), mask)
            id_patch = Image.new("I", img.size, pid)
            id_img.paste(id_patch, (px, py),
                         mask.point(lambda a: 255 if a > 40 else 0))
            if 0 <= cx < W and 0 <= cy < H:
                records.append((cx, cy, PLATE_W * p["sx"],
                                PLATE_H * p["sy"], p["cluster"]))
    return records, rough_lut, metal_lut


def periodic_field(specs):
    """Tileable low-frequency field in ~[-1, 1] from integer-frequency
    sinusoids (fx, fy, amp, phase)."""
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    f = np.zeros((H, W), dtype=np.float32)
    tot = 0.0
    for fx, fy, amp, ph in specs:
        f += amp * np.sin(2 * np.pi * (fx * xx / W + fy * yy / H) + ph)
        tot += abs(amp)
    return f / max(tot, 1e-6)


def blotch_field(spots):
    """Sum of wrap-aware gaussians (cx, cy, sx, sy), clipped to [0, 1]."""
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    f = np.zeros((H, W), dtype=np.float32)
    for cx, cy, sx, sy in spots:
        dx = np.abs(xx - cx)
        dx = np.minimum(dx, W - dx)
        dy = np.abs(yy - cy)
        dy = np.minimum(dy, H - dy)
        f += np.exp(-(dx * dx / (2 * sx * sx) + dy * dy / (2 * sy * sy)))
    return np.clip(f, 0, 1)


def band_ao_profile():
    """Per-column AO strength of the two joint bands: cosine bump,
    ramping up toward the pinch-valley edge of each band."""
    x = np.arange(W, dtype=np.float32)
    ao = np.zeros(W, dtype=np.float32)
    for center_u, valley_u in zip(BANDS, VALLEY_U):
        c = center_u * W
        d = x - c
        d = (d + W / 2) % W - W / 2
        bump = np.where(np.abs(d) < BAND_HALF,
                        np.cos(d / BAND_HALF * np.pi / 2) ** 2, 0.0)
        ramp = np.clip(0.5 + d / (2 * BAND_HALF) *
                       (1 if valley_u > center_u else -1), 0, 1)
        ao = np.maximum(ao, bump * (0.45 + 0.55 * ramp))
    return ao


def stamp_joint_height(height_arr):
    """Grooves, vent slots and fastener bumps into the height array
    (numpy, post-blur so they stay crisp for the normal conversion)."""
    h = height_arr.astype(np.float32)
    for band_i, (gu, cu) in enumerate(zip(GROOVE_U, BANDS)):
        gx = int(gu * W)
        fade = np.ones(H, dtype=np.float32)
        if band_i == 1:  # protect the head's brow/eye latitudes
            yy = np.arange(H, dtype=np.float32)
            for ey in EYE_Y:
                fade *= 1 - 0.62 * np.exp(-(((yy - ey) / 55.0) ** 2))
        for dx in range(-2, 3):
            h[:, gx + dx] -= (62 - 9 * abs(dx)) * fade
        # Vent slots: 4-slot grilles at both flanks of the band.
        cx = int(cu * W)
        for vy in (512, 1536):
            for s in range(4):
                y0 = vy - 27 + s * 16
                h[y0:y0 + 7, cx - 34:cx + 34] -= 46
        # Fastener bumps along the groove.
        r = random.Random(4242 + band_i)
        y = r.uniform(30, 90)
        while y < H - 20:
            yi = int(y)
            if not (band_i == 1 and any(abs(yi - ey) < 50 for ey in EYE_Y)):
                yy, xx = np.mgrid[yi - 8:yi + 9, gx - 8:gx + 9]
                dist = np.sqrt((xx - gx) ** 2 + (yy - yi) ** 2)
                bump = np.clip(1 - dist / 6.0, 0, 1) * 22
                moat = np.clip(1 - np.abs(dist - 7.5) / 2.5, 0, 1) * -11
                h[yi - 8:yi + 9, gx - 8:gx + 9] += bump + moat
            y += r.uniform(150, 195)
    return np.clip(h, 0, 255)


def stamp_joint_albedo(albedo_img):
    """Dark seam line, vent slots and fastener dots on the albedo."""
    d = ImageDraw.Draw(albedo_img, "RGBA")
    for band_i, (gu, cu) in enumerate(zip(GROOVE_U, BANDS)):
        gx = int(gu * W)
        d.line([gx, 0, gx, H], fill=(5, 7, 9, 235), width=4)
        cx = int(cu * W)
        for vy in (512, 1536):
            for s in range(4):
                y0 = vy - 27 + s * 16
                d.rectangle([cx - 34, y0, cx + 34, y0 + 7],
                            fill=(10, 14, 16, 255))
        r = random.Random(4242 + band_i)  # same walk as the height bumps
        y = r.uniform(30, 90)
        while y < H - 20:
            yi = int(y)
            if not (band_i == 1 and any(abs(yi - ey) < 50 for ey in EYE_Y)):
                d.ellipse([gx - 7, yi - 7, gx + 7, yi + 7],
                          fill=(9, 12, 14, 255))
                d.ellipse([gx - 2, yi - 2, gx + 2, yi + 2],
                          fill=(168, 182, 186, 255))
            y += r.uniform(150, 195)
    return albedo_img


def add_wear(albedo_img, records):
    """Scratches, gouges, smudges, speckle — at amplitudes that survive
    a game camera (Exercise 1's were near-invisible)."""
    img = albedo_img.convert("RGBA")
    d = ImageDraw.Draw(img, "RGBA")
    for _ in range(650):
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        ln = rng.uniform(8, 110)
        d.line([x, y, x + ln, y + rng.uniform(-6, 6)],
               fill=(176, 196, 200, rng.randint(20, 80)),
               width=rng.choice((1, 1, 2)))
    for _ in range(110):  # dark gouges
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        ln = rng.uniform(10, 60)
        d.line([x, y, x + ln, y + rng.uniform(-4, 4)],
               fill=(5, 7, 9, rng.randint(70, 120)), width=1)
    for (cx, cy, pw, ph, cluster) in records:  # per-plate scratch clusters
        if not cluster:
            continue
        for _ in range(rng.randint(4, 7)):
            x = cx + rng.uniform(-pw / 2, pw / 2) * 0.8
            y = cy + rng.uniform(-ph / 2, ph / 2) * 0.8
            ln = rng.uniform(14, 70)
            d.line([x, y, x + ln, y + rng.uniform(-5, 5)],
                   fill=(180, 198, 202, rng.randint(40, 95)), width=1)
    for _ in range(1500):
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        d.point((x, y), fill=(0, 0, 0, rng.randint(50, 95)))
    for _ in range(260):  # dust settled in the seams
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        d.point((x, y), fill=(102, 95, 82, rng.randint(30, 60)))
    # Smudges on their own blurred layer so they stay soft.
    sm = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ds = ImageDraw.Draw(sm)
    for _ in range(42):
        x, y = rng.uniform(0, W), rng.uniform(0, H)
        ln = rng.uniform(60, 220)
        ds.line([x, y, x + ln, y + rng.uniform(-14, 14)],
                fill=(8, 11, 13, rng.randint(14, 30)),
                width=rng.randint(4, 9))
    sm = sm.filter(ImageFilter.GaussianBlur(2))
    img.alpha_composite(sm)
    return img.convert("RGB")


def main():
    albedo = Image.new("RGB", (W, H), SEAM)
    height = Image.new("L", (W, H), 24)
    id_img = Image.new("I", (W, H), 0)
    records, rough_lut, metal_lut = draw_plates(albedo, height, id_img)

    height = height.filter(ImageFilter.GaussianBlur(2))
    h_arr = stamp_joint_height(np.asarray(height))
    height = Image.fromarray(h_arr.astype(np.uint8), "L")

    albedo = stamp_joint_albedo(albedo)

    # ---- numpy assembly: fields, wear, ORM packing
    h = h_arr / 255.0
    id_arr = np.asarray(id_img)
    mottle = periodic_field([
        (1, 2, 0.50, 0.7), (3, 1, 0.35, 2.9), (2, 3, 0.30, 5.1),
        (5, 2, 0.18, 1.3), (3, 5, 0.12, 4.2)])
    brng = random.Random(31337)
    grime = blotch_field([(brng.uniform(0, W), brng.uniform(0, H),
                           brng.uniform(120, 380), brng.uniform(120, 380))
                          for _ in range(13)])
    polish = blotch_field([(brng.uniform(0, W), brng.uniform(0, H),
                            brng.uniform(90, 220), brng.uniform(90, 220))
                           for _ in range(5)])
    gy, gx = np.gradient(h_arr)
    grad = np.sqrt(gx * gx + gy * gy)
    grad_n = np.clip(grad / max(np.percentile(grad, 99.5), 1e-6), 0, 1)
    wear = np.clip((grad_n - 0.25) / 0.75, 0, 1) ** 1.5
    valley = (1.0 - h) ** 1.6
    band_ao = band_ao_profile()[None, :, None]

    alb = np.asarray(albedo).astype(np.float32)
    alb *= (1 + 0.055 * mottle)[..., None]
    alb *= (1 - 0.13 * grime)[..., None]
    alb *= (1 - 0.16 * valley)[..., None]
    alb *= (1 - 0.30 * band_ao)
    wear_col = np.array((148, 164, 168), dtype=np.float32)
    alb = alb * (1 - 0.35 * wear[..., None]) + wear_col * (0.35 * wear[..., None])
    albedo = Image.fromarray(np.clip(alb, 0, 255).astype(np.uint8), "RGB")
    albedo = add_wear(albedo, records)

    nrng = np.random.default_rng(11)
    rough = 0.80 - 0.34 * h + rough_lut[id_arr]
    rough += 0.085 * mottle + 0.13 * grime - 0.16 * polish - 0.20 * wear
    rough += nrng.normal(0, 0.035, rough.shape)
    ao_r = np.clip(1 - 0.38 * valley - 0.50 * band_ao[..., 0], 0.25, 1)
    metal = np.clip(0.55 + metal_lut[id_arr] +
                    nrng.normal(0, 0.02, h.shape), 0.42, 0.66)
    orm = np.zeros((H, W, 3), dtype=np.uint8)
    orm[..., 0] = (ao_r * 255).astype(np.uint8)
    orm[..., 1] = (np.clip(rough, 0.28, 0.92) * 255).astype(np.uint8)
    orm[..., 2] = (metal * 255).astype(np.uint8)

    # Joint-ring emission gradient (fix #4): bright core -> dark rim
    # across V (around the torus tube); symmetric so V direction is safe.
    gv = np.linspace(0, 1, 64, dtype=np.float32)
    prof = 0.10 + 0.90 * np.cos(np.pi * (gv - 0.5)) ** 2
    # The emissive hue is BAKED INTO this texture (deep mint), not left
    # to the material color: Blender ignores a Principled emission
    # color once a texture is linked (it renders the raw texture),
    # while glTF multiplies factor x texture. Baking the tint and
    # using a white factor makes both paths produce the same color.
    # Array rows = image height = V (64), columns = U (256).
    base = np.tile(prof[:, None], (1, 256))
    glow = np.stack([base * 0.0, base * 0.62, base * 0.25], axis=-1)
    glow = (glow * 255).astype(np.uint8)

    out = "/home/hatch/workspace/snake-aaa-modeling/models/textures"
    albedo.save(f"{out}/snake_albedo.png")
    height.save(f"{out}/snake_height.png")
    Image.fromarray(orm, "RGB").save(f"{out}/snake_orm.png")
    Image.fromarray(glow, "RGB").save(f"{out}/snake_glow.png")
    print("textures written:", out)


if __name__ == "__main__":
    main()
